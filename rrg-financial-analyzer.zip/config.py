"""
Configuration settings for RRG Financial Data Analyzer
"""
import os
from datetime import datetime, timedelta

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL")
PGHOST = os.getenv("PGHOST")
PGPORT = os.getenv("PGPORT", "5432")
PGDATABASE = os.getenv("PGDATABASE")
PGUSER = os.getenv("PGUSER")
PGPASSWORD = os.getenv("PGPASSWORD")

# Construct database URL if individual components are provided
if not DATABASE_URL and all([PGHOST, PGDATABASE, PGUSER, PGPASSWORD]):
    DATABASE_URL = f"postgresql://{PGUSER}:{PGPASSWORD}@{PGHOST}:{PGPORT}/{PGDATABASE}"

# Data Configuration
YEARS_OF_DATA = 5
START_DATE = (datetime.now() - timedelta(days=YEARS_OF_DATA * 365)).strftime('%Y-%m-%d')
END_DATE = datetime.now().strftime('%Y-%m-%d')

# RRG Calculation Parameters
RRG_LONG_PERIOD = 100
RRG_SHORT_PERIOD = 14
MIN_DATA_POINTS = 150

# Benchmark Configuration
BENCHMARK_TICKER = "^NSEI"

# Cache Configuration
CACHE_TTL = 3600  # 1 hour
MAX_CACHE_SIZE = 100

# API Configuration
YFINANCE_RETRY_COUNT = 3
YFINANCE_TIMEOUT = 30

# Logging Configuration
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# UI Configuration
CHART_HEIGHT = 600
CHART_WIDTH = 800
ANIMATION_DURATION = 300

# Color Palette - Apple-inspired calming colors
COLORS = {
    'primary': '#3B82F6',      # Soft blue
    'secondary': '#8B9DC3',    # Muted blue-gray
    'success': '#10B981',      # Soft green
    'warning': '#F59E0B',      # Warm amber
    'error': '#EF4444',        # Soft red
    'background': '#FAFBFC',   # Light gray-blue
    'surface': '#F5F7FA',      # Lighter surface
    'card': '#FFFFFF',         # Pure white
    'text_primary': '#1F2937', # Dark gray
    'text_secondary': '#6B7280', # Medium gray
    'border': '#E5E7EB',       # Light border
    'accent': '#E8F4FD',       # Very light blue
    'accent_green': '#B8E0D2', # Very light green
}

# RRG Quadrant Colors
RRG_COLORS = {
    'Leading': COLORS['success'],
    'Improving': COLORS['warning'],
    'Lagging': COLORS['error'],
    'Weakening': COLORS['secondary'],
    'Neutral': '#9CA3AF'
}
