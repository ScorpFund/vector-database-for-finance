"""
RRG (Relative Rotation Graph) calculation engine
"""
import pandas as pd
import numpy as np
from typing import List, Optional
import logging

logger = logging.getLogger(__name__)

def compute_relative_strength(stock_prices: pd.Series, benchmark_prices: pd.Series, period: int = 14) -> pd.Series:
    """
    Compute relative strength ratio
    
    Args:
        stock_prices: Stock price series
        benchmark_prices: Benchmark price series  
        period: Period for calculation
        
    Returns:
        Relative strength ratio series
    """
    try:
        # Calculate percentage changes
        stock_returns = stock_prices.pct_change(period)
        benchmark_returns = benchmark_prices.pct_change(period)
        
        # Calculate relative strength
        relative_strength = (1 + stock_returns) / (1 + benchmark_returns)
        
        return relative_strength.replace([np.inf, -np.inf], np.nan)
        
    except Exception as e:
        logger.error(f"Error computing relative strength: {str(e)}")
        return pd.Series(dtype=float)

def compute_rs_momentum(rs_ratio: pd.Series, period: int = 14) -> pd.Series:
    """
    Compute RS momentum (rate of change in RS ratio)
    
    Args:
        rs_ratio: Relative strength ratio series
        period: Period for momentum calculation
        
    Returns:
        RS momentum series
    """
    try:
        rs_momentum = rs_ratio.pct_change(period) * 100
        return rs_momentum.replace([np.inf, -np.inf], np.nan)
        
    except Exception as e:
        logger.error(f"Error computing RS momentum: {str(e)}")
        return pd.Series(dtype=float)

def determine_quadrant(rs_ratio: float, rs_momentum: float, rs_ratio_100: float = 100, rs_momentum_100: float = 100) -> str:
    """
    Determine RRG quadrant based on RS ratio and momentum
    
    Args:
        rs_ratio: Current RS ratio
        rs_momentum: Current RS momentum
        rs_ratio_100: RS ratio baseline (100)
        rs_momentum_100: RS momentum baseline (100)
        
    Returns:
        Quadrant name
    """
    try:
        if pd.isna(rs_ratio) or pd.isna(rs_momentum):
            return 'Neutral'
        
        # Normalize to 100 baseline
        rs_ratio_norm = rs_ratio * 100
        rs_momentum_norm = rs_momentum
        
        if rs_ratio_norm >= rs_ratio_100 and rs_momentum_norm >= rs_momentum_100:
            return 'Leading'
        elif rs_ratio_norm < rs_ratio_100 and rs_momentum_norm >= rs_momentum_100:
            return 'Improving'
        elif rs_ratio_norm < rs_ratio_100 and rs_momentum_norm < rs_momentum_100:
            return 'Lagging'
        elif rs_ratio_norm >= rs_ratio_100 and rs_momentum_norm < rs_momentum_100:
            return 'Weakening'
        else:
            return 'Neutral'
            
    except Exception as e:
        logger.error(f"Error determining quadrant: {str(e)}")
        return 'Neutral'

def compute_rrg(price_df: pd.DataFrame, tickers: List[str], benchmark: str = "^NSEI", 
                long_period: int = 100, short_period: int = 14) -> Optional[pd.DataFrame]:
    """
    Compute RRG data for given tickers
    
    Args:
        price_df: Combined price data DataFrame
        tickers: List of stock tickers
        benchmark: Benchmark ticker
        long_period: Long period for RS calculation
        short_period: Short period for RS momentum
        
    Returns:
        DataFrame with RRG data or None if failed
    """
    try:
        if price_df.empty or not tickers:
            logger.warning("Empty price data or ticker list")
            return None
        
        # Ensure Date column is datetime
        price_df['Date'] = pd.to_datetime(price_df['Date'])
        
        # Get benchmark data
        benchmark_data = price_df[price_df['Ticker'] == benchmark].copy()
        if benchmark_data.empty:
            logger.error(f"No benchmark data found for {benchmark}")
            return None
        
        benchmark_data = benchmark_data.sort_values('Date').set_index('Date')
        benchmark_prices = benchmark_data['Close']
        
        rrg_results = []
        
        for ticker in tickers:
            try:
                # Get stock data
                stock_data = price_df[price_df['Ticker'] == ticker].copy()
                if stock_data.empty:
                    logger.warning(f"No data found for ticker {ticker}")
                    continue
                
                stock_data = stock_data.sort_values('Date').set_index('Date')
                stock_prices = stock_data['Close']
                
                # Align dates
                common_dates = stock_prices.index.intersection(benchmark_prices.index)
                if len(common_dates) < long_period:
                    logger.warning(f"Insufficient data for {ticker}: {len(common_dates)} days")
                    continue
                
                aligned_stock = stock_prices.reindex(common_dates)
                aligned_benchmark = benchmark_prices.reindex(common_dates)
                
                # Calculate RS ratio
                rs_ratio = compute_relative_strength(aligned_stock, aligned_benchmark, long_period)
                
                # Calculate RS momentum
                rs_momentum = compute_rs_momentum(rs_ratio, short_period)
                
                # Get latest values
                latest_rs_ratio = rs_ratio.iloc[-1] if not rs_ratio.empty else np.nan
                latest_rs_momentum = rs_momentum.iloc[-1] if not rs_momentum.empty else np.nan
                
                # Determine quadrant
                quadrant = determine_quadrant(latest_rs_ratio, latest_rs_momentum)
                
                rrg_results.append({
                    'Ticker': ticker,
                    'RS_Ratio': latest_rs_ratio * 100 if not pd.isna(latest_rs_ratio) else np.nan,
                    'RS_Momentum': latest_rs_momentum if not pd.isna(latest_rs_momentum) else np.nan,
                    'Quadrant': quadrant
                })
                
            except Exception as e:
                logger.warning(f"Error processing ticker {ticker}: {str(e)}")
                continue
        
        if not rrg_results:
            logger.error("No RRG results generated")
            return None
        
        rrg_df = pd.DataFrame(rrg_results)
        logger.info(f"Successfully computed RRG for {len(rrg_df)} tickers")
        
        return rrg_df
        
    except Exception as e:
        logger.error(f"Error computing RRG: {str(e)}")
        return None

def compute_rrg_historical(price_df: pd.DataFrame, tickers: List[str], benchmark: str = "^NSEI",
                          long_period: int = 100, short_period: int = 14) -> Optional[pd.DataFrame]:
    """
    Compute historical RRG data for all available dates
    
    Args:
        price_df: Combined price data DataFrame
        tickers: List of stock tickers
        benchmark: Benchmark ticker
        long_period: Long period for RS calculation
        short_period: Short period for RS momentum
        
    Returns:
        DataFrame with historical RRG data or None if failed
    """
    try:
        if price_df.empty or not tickers:
            logger.warning("Empty price data or ticker list")
            return None
        
        # Ensure Date column is datetime
        price_df['Date'] = pd.to_datetime(price_df['Date'])
        
        # Get benchmark data
        benchmark_data = price_df[price_df['Ticker'] == benchmark].copy()
        if benchmark_data.empty:
            logger.error(f"No benchmark data found for {benchmark}")
            return None
        
        benchmark_data = benchmark_data.sort_values('Date').set_index('Date')
        benchmark_prices = benchmark_data['Close']
        
        all_historical_results = []
        
        for ticker in tickers:
            try:
                # Get stock data
                stock_data = price_df[price_df['Ticker'] == ticker].copy()
                if stock_data.empty:
                    logger.warning(f"No data found for ticker {ticker}")
                    continue
                
                stock_data = stock_data.sort_values('Date').set_index('Date')
                stock_prices = stock_data['Close']
                
                # Align dates
                common_dates = stock_prices.index.intersection(benchmark_prices.index).sort_values()
                if len(common_dates) < long_period + short_period:
                    logger.warning(f"Insufficient data for {ticker}: {len(common_dates)} days")
                    continue
                
                aligned_stock = stock_prices.reindex(common_dates)
                aligned_benchmark = benchmark_prices.reindex(common_dates)
                
                # Calculate RS ratio and momentum for all dates
                rs_ratio = compute_relative_strength(aligned_stock, aligned_benchmark, long_period)
                rs_momentum = compute_rs_momentum(rs_ratio, short_period)
                
                # Create historical records
                for date in common_dates[long_period + short_period:]:  # Skip initial periods
                    try:
                        date_rs_ratio = rs_ratio.loc[date] if date in rs_ratio.index else np.nan
                        date_rs_momentum = rs_momentum.loc[date] if date in rs_momentum.index else np.nan
                        
                        if not (pd.isna(date_rs_ratio) or pd.isna(date_rs_momentum)):
                            quadrant = determine_quadrant(date_rs_ratio, date_rs_momentum)
                            
                            all_historical_results.append({
                                'Ticker': ticker,
                                'Date': date,
                                'RS_Ratio': date_rs_ratio * 100,
                                'RS_Momentum': date_rs_momentum,
                                'Quadrant': quadrant
                            })
                    except Exception as e:
                        logger.debug(f"Error processing date {date} for {ticker}: {str(e)}")
                        continue
                
            except Exception as e:
                logger.warning(f"Error processing historical data for ticker {ticker}: {str(e)}")
                continue
        
        if not all_historical_results:
            logger.error("No historical RRG results generated")
            return None
        
        historical_df = pd.DataFrame(all_historical_results)
        historical_df = historical_df.sort_values(['Date', 'Ticker']).reset_index(drop=True)
        
        logger.info(f"Successfully computed historical RRG: {len(historical_df)} records")
        
        return historical_df
        
    except Exception as e:
        logger.error(f"Error computing historical RRG: {str(e)}")
        return None
