# RRG Financial Data Analyzer

## Overview

The RRG Financial Data Analyzer is a comprehensive financial data visualization application built with Streamlit that provides Relative Rotation Graph (RRG) analysis for stock market data. The application features an Apple-inspired sleek design with PostgreSQL database integration for robust data management and real-time financial analysis.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for web application interface
- **Styling**: Custom CSS with Apple-inspired design system
- **Visualization**: Plotly for interactive financial charts and RRG graphs
- **Components**: Modular component architecture with separate modules for dashboard, sidebar, charts, and data management

### Backend Architecture
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Data Processing**: Pandas for data manipulation and analysis
- **Financial Data**: Yahoo Finance API (yfinance) for real-time market data
- **Caching**: Custom cache manager for performance optimization
- **Scheduling**: Automated daily data updates with background scheduler

### Data Layer
- **Models**: SQLAlchemy models for stock prices, RRG data, and benchmark data
- **Operations**: Centralized database operations with connection pooling
- **Validation**: Comprehensive data validation and quality checks

## Key Components

### Core Services
1. **DataService**: Manages stock price data fetching and database operations
2. **RRGService**: Handles RRG calculations and analysis
3. **PriceDataManager**: Fetches and manages historical price data
4. **NIFTY50Fetcher**: Specialized service for benchmark data collection
5. **RRGUpdater**: Automated RRG calculation updates

### Database Models
1. **StockPrice**: Stock price data with ticker, date, and close price
2. **RRGData**: RRG calculation results with RS ratio and momentum
3. **BenchmarkData**: NIFTY 50 benchmark data storage
4. **DataUpdateLog**: Audit trail for data updates

### UI Components
1. **DashboardComponent**: Main dashboard with metrics and visualizations
2. **SidebarComponent**: Navigation and control panel
3. **ChartComponents**: Interactive RRG charts and financial visualizations

## Data Flow

1. **Data Ingestion**: Yahoo Finance API fetches real-time and historical data
2. **Data Validation**: Comprehensive validation ensures data quality
3. **Database Storage**: PostgreSQL stores all financial data with proper indexing
4. **RRG Calculation**: Mathematical engine computes relative strength and momentum
5. **Visualization**: Plotly renders interactive charts and graphs
6. **Caching**: Frequently accessed data is cached for performance
7. **Scheduling**: Daily automated updates ensure data freshness

## External Dependencies

### Core Libraries
- **streamlit**: Web application framework
- **pandas**: Data manipulation and analysis
- **plotly**: Interactive visualization library
- **sqlalchemy**: Database ORM and connection management
- **yfinance**: Yahoo Finance API client
- **numpy**: Numerical computing

### Database
- **PostgreSQL**: Primary database for data storage
- **Connection pooling**: Efficient database connection management
- **Indexing**: Optimized queries with proper database indexes

### Styling
- **Custom CSS**: Apple-inspired design system
- **Inter font**: Typography matching Apple's design language
- **Responsive design**: Mobile-friendly interface

## Deployment Strategy

### Database Configuration
- Environment variables for database connection
- Support for both DATABASE_URL and individual connection parameters
- Connection pooling with SQLAlchemy for scalability
- Automated table creation and schema management

### Performance Optimization
- Multi-level caching system for expensive operations
- Background scheduling for data updates
- Connection pooling for database efficiency
- Lazy loading for large datasets

### Error Handling
- Comprehensive logging throughout the application
- Retry logic for external API calls
- Graceful degradation for missing data
- Data validation at multiple layers

## Changelog

- July 02, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.