"""
RRG Financial Data Analyzer - Simplified Application
Focus on CSV ticker management, automatic price fetching, and historical RRG data
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time
import logging
import io
import schedule
import threading
from typing import Optional, List

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import modules
from database.connection import init_database, create_tables, test_connection
from database.operations import DatabaseOperations
from services.fast_data_service import FastDataService
from services.rrg_service import RRGService
from services.scheduler import DailyScheduler
from config import COLORS, BENCHMARK_TICKER

# Page configuration
st.set_page_config(
    page_title="RRG Financial Data Analyzer",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Apple-inspired design
st.markdown("""
<style>
    .main > div {
        padding-left: 2rem;
        padding-right: 2rem;
    }
    
    .stSelectbox, .stMultiSelect {
        background-color: #f8f9fa;
    }
    
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        margin: 0.5rem 0;
    }
    
    .upload-section {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border: 2px dashed #007AFF;
        margin: 1rem 0;
    }
    
    .success-box {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    
    .info-box {
        background-color: #e7f3ff;
        color: #0066cc;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #007AFF;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize database and services
@st.cache_resource
def initialize_app():
    """Initialize database and services"""
    try:
        if init_database():
            create_tables()
            db_ops = DatabaseOperations()
            data_service = FastDataService()
            rrg_service = RRGService()
            scheduler = DailyScheduler()
            return db_ops, data_service, rrg_service, scheduler
        return None, None, None, None
    except Exception as e:
        logger.error(f"App initialization failed: {str(e)}")
        return None, None, None, None

def show_database_status():
    """Show database connection status"""
    if test_connection():
        st.success("🟢 Database Connected")
    else:
        st.error("🔴 Database Connection Failed")

def load_ticker_csv(uploaded_file) -> Optional[List[str]]:
    """Load ticker list from uploaded CSV"""
    try:
        # Read CSV file
        df = pd.read_csv(uploaded_file)
        
        # Try different possible column names for tickers
        ticker_columns = ['ticker', 'symbol', 'stock', 'Ticker', 'Symbol', 'Stock']
        ticker_column = None
        
        for col in ticker_columns:
            if col in df.columns:
                ticker_column = col
                break
        
        if ticker_column is None:
            st.error("CSV must have a column named 'ticker', 'symbol', or 'stock'")
            return None
        
        # Extract tickers and clean them
        tickers = df[ticker_column].astype(str).str.strip().str.upper().tolist()
        tickers = [t for t in tickers if t and t != 'NAN']
        
        return tickers
        
    except Exception as e:
        st.error(f"Error reading CSV file: {str(e)}")
        return None

def create_rrg_chart(rrg_data: pd.DataFrame, show_tails: bool = True) -> go.Figure:
    """Create RRG chart with optional tails"""
    
    if rrg_data.empty:
        fig = go.Figure()
        fig.add_annotation(
            text="No data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=20, color="gray")
        )
        return fig
    
    # Color mapping for quadrants
    color_map = {
        'Leading': '#28a745',      # Green
        'Improving': '#ffc107',    # Yellow
        'Lagging': '#dc3545',      # Red
        'Weakening': '#6c757d'     # Gray
    }
    
    fig = go.Figure()
    
    # Add quadrant lines
    fig.add_hline(y=100, line=dict(color='black', width=1, dash='dash'))
    fig.add_vline(x=100, line=dict(color='black', width=1, dash='dash'))
    
    # Add quadrant labels
    fig.add_annotation(x=110, y=110, text="Leading", showarrow=False, 
                      font=dict(size=14, color='#28a745'))
    fig.add_annotation(x=90, y=110, text="Improving", showarrow=False,
                      font=dict(size=14, color='#ffc107'))
    fig.add_annotation(x=90, y=90, text="Lagging", showarrow=False,
                      font=dict(size=14, color='#dc3545'))
    fig.add_annotation(x=110, y=90, text="Weakening", showarrow=False,
                      font=dict(size=14, color='#6c757d'))
    
    # Plot current positions
    for quadrant in rrg_data['Quadrant'].unique():
        quad_data = rrg_data[rrg_data['Quadrant'] == quadrant]
        
        fig.add_trace(go.Scatter(
            x=quad_data['RS_Ratio'],
            y=quad_data['RS_Momentum'],
            mode='markers+text',
            name=quadrant,
            text=quad_data['Ticker'].str.replace('.NS', ''),
            textposition='top center',
            marker=dict(
                color=color_map.get(quadrant, '#007AFF'),
                size=12,
                symbol='circle'
            ),
            hovertemplate=(
                "<b>%{text}</b><br>" +
                "RS Ratio: %{x:.2f}<br>" +
                "RS Momentum: %{y:.2f}<br>" +
                "Quadrant: " + quadrant +
                "<extra></extra>"
            )
        ))
    
    # Update layout
    fig.update_layout(
        title={
            'text': 'Relative Rotation Graph (RRG)',
            'x': 0.5,
            'font': {'size': 24}
        },
        xaxis_title='RS Ratio',
        yaxis_title='RS Momentum',
        width=800,
        height=600,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        hovermode='closest'
    )
    
    return fig

def render_ticker_management():
    """Render ticker management section"""
    st.markdown("## 📋 Ticker Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="upload-section">
            <h4>📤 Upload Ticker CSV</h4>
            <p>Upload a CSV file with your stock tickers. The CSV should have a column named 'ticker', 'symbol', or 'stock'.</p>
        </div>
        """, unsafe_allow_html=True)
        
        uploaded_file = st.file_uploader(
            "Choose CSV file",
            type=['csv'],
            help="CSV file with ticker symbols"
        )
        
        if uploaded_file is not None:
            tickers = load_ticker_csv(uploaded_file)
            
            if tickers:
                st.success(f"Found {len(tickers)} tickers in CSV")
                
                # Show preview
                with st.expander("Preview Tickers"):
                    ticker_df = pd.DataFrame({'Ticker': tickers})
                    st.dataframe(ticker_df, use_container_width=True)
                
                # Update button
                if st.button("Update Ticker List", type="primary"):
                    with st.spinner("Updating ticker list..."):
                        # Store in session state for now
                        st.session_state.ticker_list = tickers
                        st.session_state.tickers_updated = True
                        st.success("Ticker list updated! Now you can fetch price data.")
                        st.rerun()
    
    with col2:
        st.markdown("### Current Ticker List")
        
        if 'ticker_list' in st.session_state and st.session_state.ticker_list:
            current_tickers = st.session_state.ticker_list
            st.info(f"📊 {len(current_tickers)} tickers loaded")
            
            # Show current tickers
            ticker_df = pd.DataFrame({
                'Ticker': current_tickers,
                'Status': ['Ready'] * len(current_tickers)
            })
            st.dataframe(ticker_df, use_container_width=True)
            
        else:
            st.info("No tickers loaded. Please upload a CSV file.")

def render_data_management(data_service, rrg_service):
    """Render data management section"""
    st.markdown("## 💾 Data Management")
    
    # Database status
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### Database Status")
        show_database_status()
    
    with col2:
        st.markdown("### Quick Stats")
        if 'ticker_list' in st.session_state:
            st.metric("Tickers Loaded", len(st.session_state.ticker_list))
        else:
            st.metric("Tickers Loaded", 0)
    
    with col3:
        st.markdown("### Last Update")
        if 'last_data_update' in st.session_state:
            st.info(f"Last updated: {st.session_state.last_data_update}")
        else:
            st.info("No updates yet")
    
    st.divider()
    
    # Manual data fetching
    st.markdown("### 🔄 Manual Data Operations")
    
    # Prevent concurrent executions
    if 'data_fetching' not in st.session_state:
        st.session_state.data_fetching = False
    
    col1, col2 = st.columns(2)
    
    with col1:
        fetch_disabled = st.session_state.data_fetching or ('ticker_list' not in st.session_state or not st.session_state.ticker_list)
        
        if st.button("📥 Fetch All Price Data", type="primary", use_container_width=True, disabled=fetch_disabled):
            st.session_state.data_fetching = True
            
            try:
                tickers = st.session_state.ticker_list
                total_tickers = len(tickers)
                
                # Create progress tracking
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                def update_progress(current, total, message):
                    progress_bar.progress(current / total)
                    status_text.text(f"{message} ({current}/{total})")
                
                # Use fast data service with progress callback
                results = data_service.batch_fetch_tickers(tickers, update_progress)
                
                # Clear progress indicators
                progress_bar.empty()
                status_text.empty()
                
                # Show results
                success_count = len(results['success'])
                failed_count = len(results['failed'])
                
                if success_count > 0:
                    st.session_state.last_data_update = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    st.success(f"✅ Successfully fetched {success_count}/{total_tickers} tickers!")
                    
                    if failed_count > 0:
                        with st.expander(f"⚠️ {failed_count} tickers failed"):
                            st.write(results['failed'])
                else:
                    st.error("❌ Failed to fetch any ticker data")
                    if results['failed']:
                        with st.expander("Failed tickers"):
                            st.write(results['failed'])
                                
            except Exception as e:
                st.error(f"Error during data fetching: {str(e)}")
            finally:
                st.session_state.data_fetching = False
        
        if fetch_disabled and 'ticker_list' not in st.session_state:
            st.warning("Please upload ticker CSV first")
        elif st.session_state.data_fetching:
            st.info("Data fetching in progress...")
    
    with col2:
        rrg_disabled = st.session_state.get('data_fetching', False)
        
        if st.button("📊 Calculate RRG Data", type="secondary", use_container_width=True, disabled=rrg_disabled):
            with st.spinner("Calculating RRG data..."):
                success = rrg_service.update_rrg_data()
                if success:
                    st.success("RRG data calculated successfully!")
                else:
                    st.error("Failed to calculate RRG data")

def render_scheduler_management(scheduler):
    """Render scheduler management section"""
    st.markdown("## ⏰ Automatic Updates")
    
    st.markdown("""
    <div class="info-box">
        <h4>📅 Daily Schedule</h4>
        <p>The system is configured to automatically fetch new price data daily at 5:00 PM IST for all tickers and calculate RRG data.</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### Schedule Status")
        
        # Check if scheduler is running
        if scheduler and scheduler.is_running():
            st.success("🟢 Scheduler Active")
            st.info("Next update: Today at 5:00 PM IST")
        else:
            st.warning("🟡 Scheduler Inactive")
            
            if st.button("Start Daily Schedule", type="primary"):
                if scheduler:
                    scheduler.start()
                    st.success("Daily scheduler started!")
                    st.rerun()
    
    with col2:
        st.markdown("### Manual Controls")
        
        if st.button("🔄 Run Update Now", use_container_width=True):
            with st.spinner("Running daily update..."):
                # Simulate the daily update process
                if 'ticker_list' in st.session_state and st.session_state.ticker_list:
                    st.info("Fetching price data...")
                    time.sleep(2)  # Simulate processing
                    st.info("Calculating RRG data...")
                    time.sleep(1)
                    st.success("Daily update completed!")
                    st.session_state.last_data_update = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                else:
                    st.error("Please upload ticker CSV first")

def render_rrg_analysis(db_ops):
    """Render RRG analysis section"""
    st.markdown("## 📈 RRG Analysis")
    
    # Load RRG data
    try:
        rrg_data = db_ops.get_latest_rrg_data()
    except:
        rrg_data = pd.DataFrame()
    
    if rrg_data.empty:
        st.warning("No RRG data available. Please fetch price data and calculate RRG first.")
        return
    
    # Chart controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        show_tails = st.checkbox("Show Tails", value=True, help="Show historical movement trails")
    
    with col2:
        quadrant_filter = st.multiselect(
            "Filter Quadrants",
            options=["Leading", "Improving", "Lagging", "Weakening"],
            default=["Leading", "Improving", "Lagging", "Weakening"]
        )
    
    with col3:
        st.metric("Total Stocks", len(rrg_data))
    
    # Filter data
    if quadrant_filter:
        filtered_data = rrg_data[rrg_data['Quadrant'].isin(quadrant_filter)]
    else:
        filtered_data = rrg_data
    
    # Create and display RRG chart
    if not filtered_data.empty:
        rrg_chart = create_rrg_chart(filtered_data, show_tails)
        st.plotly_chart(rrg_chart, use_container_width=True)
        
        # Quadrant summary
        st.markdown("### 📊 Quadrant Summary")
        
        quadrant_counts = filtered_data['Quadrant'].value_counts()
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            leading_count = quadrant_counts.get('Leading', 0)
            st.markdown(f"""
            <div class="metric-card" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                <h4>Leading</h4>
                <h2>{leading_count}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            improving_count = quadrant_counts.get('Improving', 0)
            st.markdown(f"""
            <div class="metric-card" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                <h4>Improving</h4>
                <h2>{improving_count}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            lagging_count = quadrant_counts.get('Lagging', 0)
            st.markdown(f"""
            <div class="metric-card" style="background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);">
                <h4>Lagging</h4>
                <h2>{lagging_count}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            weakening_count = quadrant_counts.get('Weakening', 0)
            st.markdown(f"""
            <div class="metric-card" style="background: linear-gradient(135deg, #6c757d 0%, #495057 100%);">
                <h4>Weakening</h4>
                <h2>{weakening_count}</h2>
            </div>
            """, unsafe_allow_html=True)
        
        # Data table
        st.markdown("### 📋 Detailed Data")
        
        display_data = filtered_data.copy()
        display_data['Ticker'] = display_data['Ticker'].str.replace('.NS', '')
        display_data = display_data[['Ticker', 'RS_Ratio', 'RS_Momentum', 'Quadrant']]
        display_data = display_data.round(2)
        
        st.dataframe(display_data, use_container_width=True)

def main():
    """Main application function"""
    
    # Initialize app
    db_ops, data_service, rrg_service, scheduler = initialize_app()
    
    if not db_ops:
        st.error("Failed to initialize application. Please check database connection.")
        return
    
    # App header
    st.markdown("""
    # 📈 RRG Financial Data Analyzer
    *Automated daily price fetching with historical RRG analysis*
    """)
    
    # Sidebar navigation
    st.sidebar.markdown("## Navigation")
    
    page = st.sidebar.selectbox(
        "Choose a page",
        ["Ticker Management", "Data Management", "Scheduler", "RRG Analysis"]
    )
    
    # Render selected page
    if page == "Ticker Management":
        render_ticker_management()
    
    elif page == "Data Management":
        render_data_management(data_service, rrg_service)
    
    elif page == "Scheduler":
        render_scheduler_management(scheduler)
    
    elif page == "RRG Analysis":
        render_rrg_analysis(db_ops)
    
    # Footer
    st.sidebar.markdown("---")
    st.sidebar.markdown("**RRG Analyzer v2.0**")
    st.sidebar.markdown("*Apple-inspired design*")

if __name__ == "__main__":
    main()