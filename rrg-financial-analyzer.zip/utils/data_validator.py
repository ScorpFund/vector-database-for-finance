"""
Data validation utilities
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
from utils.logger import setup_logger

logger = setup_logger(__name__)

class DataValidator:
    """Handles data validation and quality checks"""
    
    @staticmethod
    def validate_ticker_format(ticker: str) -> bool:
        """Validate ticker symbol format"""
        if not ticker or not isinstance(ticker, str):
            return False
        
        ticker = ticker.strip().upper()
        # Basic validation - alphanumeric characters and dots
        return ticker.replace('.', '').isalnum() and len(ticker) > 0
    
    @staticmethod
    def validate_price_data(df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """
        Validate price data DataFrame
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        if df is None or df.empty:
            errors.append("DataFrame is empty or None")
            return False, errors
        
        # Check required columns
        required_columns = ['Date', 'Close', 'Ticker']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            errors.append(f"Missing required columns: {missing_columns}")
        
        # Check data types
        if 'Date' in df.columns:
            try:
                pd.to_datetime(df['Date'])
            except:
                errors.append("Date column contains invalid datetime values")
        
        if 'Close' in df.columns:
            if not pd.api.types.is_numeric_dtype(df['Close']):
                errors.append("Close column must contain numeric values")
            elif df['Close'].isna().all():
                errors.append("Close column contains only NaN values")
            elif (df['Close'] <= 0).any():
                errors.append("Close column contains non-positive values")
        
        # Check for duplicate entries
        if len(df) > 0 and 'Date' in df.columns and 'Ticker' in df.columns:
            duplicates = df.duplicated(subset=['Date', 'Ticker']).sum()
            if duplicates > 0:
                errors.append(f"Found {duplicates} duplicate Date-Ticker combinations")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_rrg_data(df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """
        Validate RRG data DataFrame
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        if df is None or df.empty:
            errors.append("RRG DataFrame is empty or None")
            return False, errors
        
        # Check required columns
        required_columns = ['Ticker', 'RS_Ratio', 'RS_Momentum', 'Quadrant']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            errors.append(f"Missing required RRG columns: {missing_columns}")
        
        # Check for NaN values in critical columns
        if 'RS_Ratio' in df.columns and df['RS_Ratio'].isna().any():
            nan_count = df['RS_Ratio'].isna().sum()
            errors.append(f"RS_Ratio contains {nan_count} NaN values")
        
        if 'RS_Momentum' in df.columns and df['RS_Momentum'].isna().any():
            nan_count = df['RS_Momentum'].isna().sum()
            errors.append(f"RS_Momentum contains {nan_count} NaN values")
        
        # Check quadrant values
        if 'Quadrant' in df.columns:
            valid_quadrants = ['Leading', 'Improving', 'Lagging', 'Weakening', 'Neutral']
            invalid_quadrants = df[~df['Quadrant'].isin(valid_quadrants)]['Quadrant'].unique()
            if len(invalid_quadrants) > 0:
                errors.append(f"Invalid quadrant values found: {invalid_quadrants}")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def get_data_quality_report(df: pd.DataFrame) -> Dict[str, Any]:
        """Generate comprehensive data quality report"""
        if df is None or df.empty:
            return {"status": "error", "message": "No data provided"}
        
        report = {
            "total_rows": len(df),
            "total_columns": len(df.columns),
            "memory_usage": df.memory_usage(deep=True).sum() / 1024 / 1024,  # MB
            "columns": {}
        }
        
        for col in df.columns:
            col_info = {
                "dtype": str(df[col].dtype),
                "null_count": df[col].isna().sum(),
                "null_percentage": (df[col].isna().sum() / len(df)) * 100,
                "unique_count": df[col].nunique()
            }
            
            if pd.api.types.is_numeric_dtype(df[col]):
                col_info.update({
                    "min": df[col].min(),
                    "max": df[col].max(),
                    "mean": df[col].mean(),
                    "std": df[col].std()
                })
            
            report["columns"][col] = col_info
        
        return report
