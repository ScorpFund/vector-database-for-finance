"""
Cache management utilities for improved performance
"""
import streamlit as st
import pandas as pd
import hashlib
from typing import Any, Optional
from config import CACHE_TTL, MAX_CACHE_SIZE
from utils.logger import setup_logger

logger = setup_logger(__name__)

class CacheManager:
    """Manages caching of expensive operations"""
    
    def __init__(self):
        if 'cache_store' not in st.session_state:
            st.session_state.cache_store = {}
        if 'cache_timestamps' not in st.session_state:
            st.session_state.cache_timestamps = {}
    
    def _generate_key(self, *args, **kwargs) -> str:
        """Generate a unique cache key from arguments"""
        key_string = str(args) + str(sorted(kwargs.items()))
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """Get cached value if valid"""
        if key in st.session_state.cache_store:
            import time
            if (time.time() - st.session_state.cache_timestamps.get(key, 0)) < CACHE_TTL:
                logger.debug(f"Cache hit for key: {key}")
                return st.session_state.cache_store[key]
            else:
                # Remove expired cache
                self._remove(key)
        return None
    
    def set(self, key: str, value: Any) -> None:
        """Set cached value with timestamp"""
        import time
        
        # Limit cache size
        if len(st.session_state.cache_store) >= MAX_CACHE_SIZE:
            self._cleanup_oldest()
        
        st.session_state.cache_store[key] = value
        st.session_state.cache_timestamps[key] = time.time()
        logger.debug(f"Cached value for key: {key}")
    
    def _remove(self, key: str) -> None:
        """Remove specific cache entry"""
        st.session_state.cache_store.pop(key, None)
        st.session_state.cache_timestamps.pop(key, None)
    
    def _cleanup_oldest(self) -> None:
        """Remove oldest cache entries to make space"""
        if not st.session_state.cache_timestamps:
            return
        
        oldest_key = min(st.session_state.cache_timestamps.items(), key=lambda x: x[1])[0]
        self._remove(oldest_key)
        logger.debug(f"Removed oldest cache entry: {oldest_key}")
    
    def clear(self) -> None:
        """Clear all cache"""
        st.session_state.cache_store.clear()
        st.session_state.cache_timestamps.clear()
        logger.info("Cache cleared")

# Global cache manager instance
cache_manager = CacheManager()

def cached_function(func):
    """Decorator for caching function results"""
    def wrapper(*args, **kwargs):
        key = cache_manager._generate_key(func.__name__, *args, **kwargs)
        
        # Try to get from cache
        result = cache_manager.get(key)
        if result is not None:
            return result
        
        # Compute and cache result
        result = func(*args, **kwargs)
        cache_manager.set(key, result)
        return result
    
    return wrapper
