"""
Database operations for RRG Financial Data Analyzer
"""
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy import text, and_, desc
from sqlalchemy.orm import Session
from database.connection import get_db_session
from database.models import StockPrice, RRGData, BenchmarkData, DataUpdateLog
import logging

logger = logging.getLogger(__name__)

class DatabaseOperations:
    """Handle all database operations"""
    
    @staticmethod
    def save_stock_prices(df: pd.DataFrame) -> bool:
        """Save stock price data to database"""
        try:
            with get_db_session() as session:
                records_added = 0
                
                for _, row in df.iterrows():
                    # Check if record exists
                    existing = session.query(StockPrice).filter(
                        and_(
                            StockPrice.ticker == row['Ticker'],
                            StockPrice.date == pd.to_datetime(row['Date'])
                        )
                    ).first()
                    
                    if not existing:
                        price_record = StockPrice(
                            ticker=row['Ticker'],
                            date=pd.to_datetime(row['Date']),
                            close_price=float(row['Close'])
                        )
                        session.add(price_record)
                        records_added += 1
                    else:
                        # Update existing record
                        existing.close_price = float(row['Close'])
                        existing.updated_at = datetime.now()
                
                session.commit()
                logger.info(f"Saved {records_added} stock price records")
                return True
                
        except Exception as e:
            logger.error(f"Error saving stock prices: {str(e)}")
            return False
    
    @staticmethod
    def save_rrg_data(df: pd.DataFrame) -> bool:
        """Save RRG data to database"""
        try:
            with get_db_session() as session:
                records_added = 0
                
                for _, row in df.iterrows():
                    # Check if record exists
                    existing = session.query(RRGData).filter(
                        and_(
                            RRGData.ticker == row['Ticker'],
                            RRGData.date == pd.to_datetime(row['Date'])
                        )
                    ).first()
                    
                    if not existing:
                        rrg_record = RRGData(
                            ticker=row['Ticker'],
                            date=pd.to_datetime(row['Date']),
                            rs_ratio=float(row['RS_Ratio']),
                            rs_momentum=float(row['RS_Momentum']),
                            quadrant=row['Quadrant']
                        )
                        session.add(rrg_record)
                        records_added += 1
                    else:
                        # Update existing record
                        existing.rs_ratio = float(row['RS_Ratio'])
                        existing.rs_momentum = float(row['RS_Momentum'])
                        existing.quadrant = row['Quadrant']
                        existing.updated_at = datetime.now()
                
                session.commit()
                logger.info(f"Saved {records_added} RRG data records")
                return True
                
        except Exception as e:
            logger.error(f"Error saving RRG data: {str(e)}")
            return False
    
    @staticmethod
    def save_benchmark_data(df: pd.DataFrame) -> bool:
        """Save benchmark data to database"""
        try:
            with get_db_session() as session:
                records_added = 0
                
                for _, row in df.iterrows():
                    # Check if record exists
                    existing = session.query(BenchmarkData).filter(
                        and_(
                            BenchmarkData.ticker == row['Ticker'],
                            BenchmarkData.date == pd.to_datetime(row['Date'])
                        )
                    ).first()
                    
                    if not existing:
                        benchmark_record = BenchmarkData(
                            ticker=row['Ticker'],
                            date=pd.to_datetime(row['Date']),
                            close_price=float(row['Close'])
                        )
                        session.add(benchmark_record)
                        records_added += 1
                    else:
                        # Update existing record
                        existing.close_price = float(row['Close'])
                        existing.updated_at = datetime.now()
                
                session.commit()
                logger.info(f"Saved {records_added} benchmark data records")
                return True
                
        except Exception as e:
            logger.error(f"Error saving benchmark data: {str(e)}")
            return False
    
    @staticmethod
    def get_stock_prices(tickers: List[str] = None, start_date: datetime = None, end_date: datetime = None) -> pd.DataFrame:
        """Get stock price data from database"""
        try:
            with get_db_session() as session:
                query = session.query(StockPrice)
                
                if tickers:
                    query = query.filter(StockPrice.ticker.in_(tickers))
                
                if start_date:
                    query = query.filter(StockPrice.date >= start_date)
                
                if end_date:
                    query = query.filter(StockPrice.date <= end_date)
                
                query = query.order_by(StockPrice.ticker, StockPrice.date)
                
                results = query.all()
                
                if not results:
                    return pd.DataFrame()
                
                data = []
                for record in results:
                    data.append({
                        'Ticker': record.ticker,
                        'Date': record.date,
                        'Close': record.close_price
                    })
                
                return pd.DataFrame(data)
                
        except Exception as e:
            logger.error(f"Error getting stock prices: {str(e)}")
            return pd.DataFrame()
    
    @staticmethod
    def get_rrg_data(tickers: List[str] = None, start_date: datetime = None, end_date: datetime = None) -> pd.DataFrame:
        """Get RRG data from database"""
        try:
            with get_db_session() as session:
                query = session.query(RRGData)
                
                if tickers:
                    query = query.filter(RRGData.ticker.in_(tickers))
                
                if start_date:
                    query = query.filter(RRGData.date >= start_date)
                
                if end_date:
                    query = query.filter(RRGData.date <= end_date)
                
                query = query.order_by(RRGData.ticker, RRGData.date)
                
                results = query.all()
                
                if not results:
                    return pd.DataFrame()
                
                data = []
                for record in results:
                    data.append({
                        'Ticker': record.ticker,
                        'Date': record.date,
                        'RS_Ratio': record.rs_ratio,
                        'RS_Momentum': record.rs_momentum,
                        'Quadrant': record.quadrant
                    })
                
                return pd.DataFrame(data)
                
        except Exception as e:
            logger.error(f"Error getting RRG data: {str(e)}")
            return pd.DataFrame()
    
    @staticmethod
    def get_benchmark_data(start_date: datetime = None, end_date: datetime = None) -> pd.DataFrame:
        """Get benchmark data from database"""
        try:
            with get_db_session() as session:
                query = session.query(BenchmarkData)
                
                if start_date:
                    query = query.filter(BenchmarkData.date >= start_date)
                
                if end_date:
                    query = query.filter(BenchmarkData.date <= end_date)
                
                query = query.order_by(BenchmarkData.date)
                
                results = query.all()
                
                if not results:
                    return pd.DataFrame()
                
                data = []
                for record in results:
                    data.append({
                        'Ticker': record.ticker,
                        'Date': record.date,
                        'Close': record.close_price
                    })
                
                return pd.DataFrame(data)
                
        except Exception as e:
            logger.error(f"Error getting benchmark data: {str(e)}")
            return pd.DataFrame()
    
    @staticmethod
    def get_latest_rrg_data() -> pd.DataFrame:
        """Get the most recent RRG data"""
        try:
            with get_db_session() as session:
                # Get the latest date
                latest_date_result = session.query(RRGData.date).order_by(desc(RRGData.date)).first()
                
                if not latest_date_result:
                    return pd.DataFrame()
                
                latest_date = latest_date_result[0]
                
                # Get all data for the latest date
                results = session.query(RRGData).filter(
                    RRGData.date == latest_date
                ).all()
                
                data = []
                for record in results:
                    data.append({
                        'Ticker': record.ticker,
                        'Date': record.date,
                        'RS_Ratio': record.rs_ratio,
                        'RS_Momentum': record.rs_momentum,
                        'Quadrant': record.quadrant
                    })
                
                return pd.DataFrame(data)
                
        except Exception as e:
            logger.error(f"Error getting latest RRG data: {str(e)}")
            return pd.DataFrame()
    
    @staticmethod
    def get_data_summary() -> Dict[str, Any]:
        """Get summary of all data in database"""
        try:
            with get_db_session() as session:
                summary = {}
                
                # Stock prices summary
                stock_count = session.query(StockPrice).count()
                unique_tickers = session.query(StockPrice.ticker).distinct().count()
                summary['stock_prices'] = {
                    'total_records': stock_count,
                    'unique_tickers': unique_tickers
                }
                
                # RRG data summary
                rrg_count = session.query(RRGData).count()
                rrg_tickers = session.query(RRGData.ticker).distinct().count()
                latest_rrg_date = session.query(RRGData.date).order_by(desc(RRGData.date)).first()
                summary['rrg_data'] = {
                    'total_records': rrg_count,
                    'unique_tickers': rrg_tickers,
                    'latest_date': latest_rrg_date[0] if latest_rrg_date else None
                }
                
                # Benchmark data summary
                benchmark_count = session.query(BenchmarkData).count()
                summary['benchmark_data'] = {
                    'total_records': benchmark_count
                }
                
                return summary
                
        except Exception as e:
            logger.error(f"Error getting data summary: {str(e)}")
            return {}
    
    @staticmethod
    def log_data_update(update_type: str, status: str, records_processed: int = 0, 
                       error_message: str = None, started_at: datetime = None) -> None:
        """Log data update operation"""
        try:
            with get_db_session() as session:
                log_entry = DataUpdateLog(
                    update_type=update_type,
                    status=status,
                    records_processed=records_processed,
                    error_message=error_message,
                    started_at=started_at or datetime.now(),
                    completed_at=datetime.now() if status in ['success', 'failed'] else None
                )
                session.add(log_entry)
                session.commit()
                
        except Exception as e:
            logger.error(f"Error logging data update: {str(e)}")
