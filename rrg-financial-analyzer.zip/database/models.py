"""
Database models for RRG Financial Data Analyzer
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Index, UniqueConstraint
from sqlalchemy.sql import func
from database.connection import Base
import pandas as pd
from typing import List, Optional

class StockPrice(Base):
    """Stock price data model"""
    __tablename__ = "stock_prices"
    
    id = Column(Integer, primary_key=True, index=True)
    ticker = Column(String(20), nullable=False, index=True)
    date = Column(DateTime, nullable=False, index=True)
    close_price = Column(Float, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        UniqueConstraint('ticker', 'date', name='unique_ticker_date'),
        Index('idx_ticker_date', 'ticker', 'date'),
    )

class RRGData(Base):
    """RRG calculation results model"""
    __tablename__ = "rrg_data"
    
    id = Column(Integer, primary_key=True, index=True)
    ticker = Column(String(20), nullable=False, index=True)
    date = Column(DateTime, nullable=False, index=True)
    rs_ratio = Column(Float, nullable=False)
    rs_momentum = Column(Float, nullable=False)
    quadrant = Column(String(20), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        UniqueConstraint('ticker', 'date', name='unique_rrg_ticker_date'),
        Index('idx_rrg_ticker_date', 'ticker', 'date'),
        Index('idx_quadrant', 'quadrant'),
    )

class BenchmarkData(Base):
    """Benchmark (NIFTY 50) data model"""
    __tablename__ = "benchmark_data"
    
    id = Column(Integer, primary_key=True, index=True)
    ticker = Column(String(20), nullable=False, default="^NSEI")
    date = Column(DateTime, nullable=False, index=True)
    close_price = Column(Float, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        UniqueConstraint('ticker', 'date', name='unique_benchmark_ticker_date'),
        Index('idx_benchmark_date', 'date'),
    )

class DataUpdateLog(Base):
    """Log of data updates"""
    __tablename__ = "data_update_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    update_type = Column(String(50), nullable=False)  # 'stock_prices', 'rrg_data', 'benchmark'
    status = Column(String(20), nullable=False)  # 'success', 'failed', 'partial'
    records_processed = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    started_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    
    __table_args__ = (
        Index('idx_update_type_status', 'update_type', 'status'),
        Index('idx_started_at', 'started_at'),
    )

# Pydantic models for API responses (optional)
class StockPriceResponse:
    """Response model for stock price data"""
    def __init__(self, ticker: str, date: str, close_price: float):
        self.ticker = ticker
        self.date = date
        self.close_price = close_price

class RRGDataResponse:
    """Response model for RRG data"""
    def __init__(self, ticker: str, date: str, rs_ratio: float, rs_momentum: float, quadrant: str):
        self.ticker = ticker
        self.date = date
        self.rs_ratio = rs_ratio
        self.rs_momentum = rs_momentum
        self.quadrant = quadrant
