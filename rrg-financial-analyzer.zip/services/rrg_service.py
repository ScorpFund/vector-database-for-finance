"""
Simplified RRG calculation service
"""
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Optional
from config import BENCHMARK_TICKER
from database.operations import DatabaseOperations
from rrg_calculator import compute_rrg, compute_rrg_historical
import logging

logger = logging.getLogger(__name__)

class RRGService:
    """Handles RRG calculation and data management"""
    
    def __init__(self):
        self.db_ops = DatabaseOperations()
    
    def calculate_current_rrg(self) -> Optional[pd.DataFrame]:
        """Calculate current RRG snapshot"""
        try:
            # Load combined data from database
            combined_df = self._load_combined_data()
            if combined_df is None or combined_df.empty:
                logger.error("No data available for RRG calculation")
                return None
            
            # Get stock tickers (excluding benchmark)
            tickers = self._get_stock_tickers(combined_df)
            if not tickers:
                logger.error("No stock tickers found")
                return None
            
            # Calculate RRG for latest date
            rrg_data = compute_rrg(combined_df, tickers, BENCHMARK_TICKER)
            
            if rrg_data is not None and not rrg_data.empty:
                logger.info(f"Calculated RRG for {len(rrg_data)} stocks")
                return rrg_data
            else:
                logger.error("RRG calculation returned empty result")
                return None
                
        except Exception as e:
            logger.error(f"Error calculating current RRG: {str(e)}")
            return None
    
    def calculate_historical_rrg(self) -> Optional[pd.DataFrame]:
        """Calculate historical RRG data for all dates"""
        try:
            # Load combined data from database
            combined_df = self._load_combined_data()
            if combined_df is None or combined_df.empty:
                logger.error("No data available for historical RRG calculation")
                return None
            
            # Get stock tickers (excluding benchmark)
            tickers = self._get_stock_tickers(combined_df)
            if not tickers:
                logger.error("No stock tickers found")
                return None
            
            # Calculate historical RRG
            historical_rrg = compute_rrg_historical(combined_df, tickers, BENCHMARK_TICKER)
            
            if historical_rrg is not None and not historical_rrg.empty:
                logger.info(f"Calculated historical RRG: {len(historical_rrg)} records")
                return historical_rrg
            else:
                logger.error("Historical RRG calculation returned empty result")
                return None
                
        except Exception as e:
            logger.error(f"Error calculating historical RRG: {str(e)}")
            return None
    
    def update_rrg_data(self) -> bool:
        """Update RRG data with latest calculations"""
        try:
            logger.info("Starting RRG data update...")
            
            # Calculate current RRG
            current_rrg = self.calculate_current_rrg()
            if current_rrg is None:
                logger.error("Failed to calculate current RRG")
                return False
            
            # Add current date to the data
            current_rrg['Date'] = datetime.now().date()
            
            # Save to database
            success = self.db_ops.save_rrg_data(current_rrg)
            
            if success:
                logger.info(f"✅ RRG data updated successfully ({len(current_rrg)} records)")
                return True
            else:
                logger.error("Failed to save RRG data to database")
                return False
                
        except Exception as e:
            logger.error(f"Error updating RRG data: {str(e)}")
            return False
    
    def _load_combined_data(self) -> Optional[pd.DataFrame]:
        """Load and combine price and benchmark data"""
        try:
            # Load stock prices
            stock_data = self.db_ops.get_stock_prices()
            if stock_data.empty:
                logger.error("No stock price data found")
                return None
            
            # Load benchmark data
            benchmark_data = self.db_ops.get_benchmark_data()
            if benchmark_data.empty:
                logger.error("No benchmark data found")
                return None
            
            # Combine data
            combined_df = pd.concat([stock_data, benchmark_data], ignore_index=True)
            combined_df['Date'] = pd.to_datetime(combined_df['Date'])
            
            logger.info(f"Combined data loaded: {len(combined_df)} records")
            return combined_df
            
        except Exception as e:
            logger.error(f"Error loading combined data: {str(e)}")
            return None
    
    def _get_stock_tickers(self, combined_df: pd.DataFrame) -> list:
        """Get list of stock tickers excluding benchmark"""
        try:
            all_tickers = combined_df['Ticker'].unique().tolist()
            stock_tickers = [t for t in all_tickers if t != BENCHMARK_TICKER]
            return stock_tickers
        except Exception as e:
            logger.error(f"Error getting stock tickers: {str(e)}")
            return []
    
    def get_rrg_summary(self) -> dict:
        """Get RRG data summary"""
        try:
            # Get basic summary from database operations
            summary = self.db_ops.get_data_summary()
            
            if 'rrg_data' not in summary:
                return {'exists': False, 'message': 'No RRG data found'}
            
            return {
                'exists': True,
                'total_records': summary['rrg_data'].get('total_records', 0),
                'unique_tickers': summary['rrg_data'].get('unique_tickers', 0),
                'latest_date': summary['rrg_data'].get('latest_date')
            }
            
        except Exception as e:
            logger.error(f"Error getting RRG summary: {str(e)}")
            return {'exists': False, 'error': str(e)}
    
    def load_historical_rrg_data(self, days: int = 30) -> Optional[pd.DataFrame]:
        """Load historical RRG data for specified number of days"""
        try:
            # Calculate date range
            end_date = datetime.now()
            start_date = end_date - pd.Timedelta(days=days)
            
            # Load historical data from database
            historical_data = self.db_ops.get_rrg_data(start_date=start_date, end_date=end_date)
            
            if not historical_data.empty:
                logger.info(f"Loaded {len(historical_data)} historical RRG records")
                return historical_data
            else:
                logger.warning("No historical RRG data found")
                return None
                
        except Exception as e:
            logger.error(f"Error loading historical RRG data: {str(e)}")
            return None