"""
Enhanced NIFTY 50 data fetcher with database integration
"""
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
from config import (
    BENCHMARK_TICKER, YEARS_OF_DATA,
    START_DATE, END_DATE, YFINANCE_RETRY_COUNT, YFINANCE_TIMEOUT
)
from utils.logger import setup_logger, log_function_call
from utils.data_validator import DataValidator
from database.operations import DatabaseOperations

logger = setup_logger(__name__)

class NIFTY50Fetcher:
    """Enhanced NIFTY 50 data fetcher with database integration"""
    
    def __init__(self):
        self.ticker = BENCHMARK_TICKER
        self.validator = DataValidator()
        self.db_ops = DatabaseOperations()
    
    @log_function_call
    def fetch_nifty50(self) -> bool:
        """
        Fetch NIFTY 50 data with retry logic and save to database
        
        Returns:
            bool: Success status
        """
        try:
            logger.info(f"Fetching {YEARS_OF_DATA}Y of data for {self.ticker}")
            
            # Attempt to fetch data with retry logic
            df = None
            for attempt in range(YFINANCE_RETRY_COUNT):
                try:
                    logger.debug(f"Fetch attempt {attempt + 1} for {self.ticker}")
                    
                    df = yf.download(
                        self.ticker,
                        start=START_DATE,
                        end=END_DATE,
                        progress=False,
                        timeout=YFINANCE_TIMEOUT
                    )
                    
                    if df is not None and not df.empty:
                        break
                    else:
                        logger.warning(f"Attempt {attempt + 1}: No data returned for {self.ticker}")
                        
                except Exception as e:
                    logger.warning(f"Attempt {attempt + 1} failed for {self.ticker}: {str(e)}")
                    if attempt == YFINANCE_RETRY_COUNT - 1:
                        raise
            
            if df is None or df.empty:
                logger.error(f"No data returned after {YFINANCE_RETRY_COUNT} attempts")
                return False
            
            # Handle multi-level columns from yfinance
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.droplevel(1)
                logger.debug("Handled multi-level columns from yfinance")
            
            # Prepare data
            df = df[['Close']].reset_index()
            df['Ticker'] = self.ticker
            
            # Validate data
            is_valid, errors = self.validator.validate_price_data(df)
            if not is_valid:
                logger.error(f"Data validation failed: {errors}")
                return False
            
            # Additional validation specific to NIFTY 50
            if not self._validate_nifty_data(df):
                return False
            
            # Save to database
            success = self.db_ops.save_benchmark_data(df)
            
            if success:
                logger.info(f"✅ Saved NIFTY 50 data to database ({len(df)} rows)")
                return True
            else:
                logger.error("Failed to save NIFTY 50 data to database")
                return False
            
        except Exception as e:
            logger.error(f"Error fetching NIFTY 50 data: {str(e)}")
            return False
    
    def _validate_nifty_data(self, df: pd.DataFrame) -> bool:
        """
        Perform additional validation specific to NIFTY 50 data
        
        Args:
            df: DataFrame to validate
            
        Returns:
            bool: Validation success status
        """
        try:
            # Check date range
            df['Date'] = pd.to_datetime(df['Date'])
            date_range = (df['Date'].max() - df['Date'].min()).days
            
            if date_range < (YEARS_OF_DATA * 365 * 0.8):  # Allow 20% tolerance
                logger.warning(f"Date range shorter than expected: {date_range} days")
            
            # Check for reasonable price values
            close_prices = df['Close']
            if close_prices.min() <= 0:
                logger.error("Found non-positive close prices")
                return False
            
            # Check for extreme price movements (daily changes > 20%)
            price_changes = close_prices.pct_change().abs()
            extreme_changes = price_changes > 0.20
            
            if extreme_changes.any():
                extreme_count = extreme_changes.sum()
                logger.warning(f"Found {extreme_count} extreme daily price changes (>20%)")
                
                # If too many extreme changes, it might indicate data quality issues
                if extreme_count > len(df) * 0.01:  # More than 1% of data points
                    logger.error("Too many extreme price changes, data quality suspect")
                    return False
            
            logger.debug("NIFTY 50 data validation passed")
            return True
            
        except Exception as e:
            logger.error(f"Error validating NIFTY 50 data: {str(e)}")
            return False
