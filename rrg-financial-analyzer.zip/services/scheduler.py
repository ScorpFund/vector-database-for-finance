"""
Daily scheduler for automatic price fetching and RRG calculation at 5:00 PM IST
"""
import schedule
import time
import threading
import logging
from datetime import datetime
from typing import Optional
from services.data_service import DataService
from services.rrg_service import RRGService
from services.nifty50_fetcher import NIFTY50Fetcher

logger = logging.getLogger(__name__)

class DailyScheduler:
    """Manages daily automatic updates at 5:00 PM IST"""
    
    def __init__(self):
        self.data_service = DataService()
        self.rrg_service = RRGService()
        self.nifty_fetcher = NIFTY50Fetcher()
        self.is_running_flag = False
        self.scheduler_thread: Optional[threading.Thread] = None
        
    def daily_update_job(self):
        """Main job that runs daily at 5:00 PM IST"""
        try:
            logger.info("🚀 Starting daily update job...")
            start_time = datetime.now()
            
            # Step 1: Fetch NIFTY 50 benchmark data
            logger.info("📈 Fetching NIFTY 50 benchmark data...")
            nifty_success = self.nifty_fetcher.fetch_nifty50()
            if nifty_success:
                logger.info("✅ NIFTY 50 data updated")
            else:
                logger.error("❌ Failed to update NIFTY 50 data")
            
            # Step 2: Fetch all stock prices
            logger.info("💰 Fetching stock price data...")
            price_success = self.data_service.refresh_all_data()
            if price_success:
                logger.info("✅ Stock price data updated")
            else:
                logger.error("❌ Failed to update stock price data")
            
            # Step 3: Calculate RRG data
            logger.info("📊 Calculating RRG data...")
            rrg_success = self.rrg_service.update_rrg_data()
            if rrg_success:
                logger.info("✅ RRG data updated")
            else:
                logger.error("❌ Failed to update RRG data")
            
            # Summary
            end_time = datetime.now()
            duration = end_time - start_time
            
            success_count = sum([nifty_success, price_success, rrg_success])
            
            if success_count == 3:
                logger.info(f"🎉 Daily update completed successfully in {duration.total_seconds():.1f} seconds")
            elif success_count > 0:
                logger.warning(f"⚠️ Daily update partially completed ({success_count}/3) in {duration.total_seconds():.1f} seconds")
            else:
                logger.error(f"💥 Daily update failed completely in {duration.total_seconds():.1f} seconds")
                
        except Exception as e:
            logger.error(f"💥 Daily update job failed with error: {str(e)}")
    
    def start(self):
        """Start the daily scheduler"""
        if self.is_running_flag:
            logger.warning("Scheduler is already running")
            return
        
        try:
            # Schedule daily job at 5:00 PM IST
            schedule.clear()  # Clear any existing schedules
            schedule.every().day.at("17:00").do(self.daily_update_job)
            
            self.is_running_flag = True
            
            # Start scheduler in a separate thread
            self.scheduler_thread = threading.Thread(target=self._run_scheduler, daemon=True)
            self.scheduler_thread.start()
            
            logger.info("⏰ Daily scheduler started - will run at 5:00 PM IST every day")
            
        except Exception as e:
            logger.error(f"Failed to start scheduler: {str(e)}")
            self.is_running_flag = False
    
    def stop(self):
        """Stop the daily scheduler"""
        if not self.is_running_flag:
            logger.warning("Scheduler is not running")
            return
        
        try:
            self.is_running_flag = False
            schedule.clear()
            
            if self.scheduler_thread and self.scheduler_thread.is_alive():
                # Wait for thread to finish (with timeout)
                self.scheduler_thread.join(timeout=5.0)
            
            logger.info("⏹️ Daily scheduler stopped")
            
        except Exception as e:
            logger.error(f"Error stopping scheduler: {str(e)}")
    
    def _run_scheduler(self):
        """Internal method to run the scheduler loop"""
        while self.is_running_flag:
            try:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
            except Exception as e:
                logger.error(f"Scheduler loop error: {str(e)}")
                time.sleep(60)  # Continue running even if there's an error
    
    def is_running(self) -> bool:
        """Check if scheduler is currently running"""
        return self.is_running_flag
    
    def get_next_run_time(self) -> Optional[str]:
        """Get the next scheduled run time"""
        try:
            jobs = schedule.get_jobs()
            if jobs:
                next_run = jobs[0].next_run
                if next_run:
                    return next_run.strftime("%Y-%m-%d %H:%M:%S")
            return None
        except Exception as e:
            logger.error(f"Error getting next run time: {str(e)}")
            return None
    
    def run_now(self):
        """Manually trigger the daily update job"""
        try:
            logger.info("🔄 Manually triggering daily update job...")
            self.daily_update_job()
        except Exception as e:
            logger.error(f"Manual update failed: {str(e)}")
    
    def get_status(self) -> dict:
        """Get scheduler status information"""
        return {
            'is_running': self.is_running(),
            'next_run_time': self.get_next_run_time(),
            'scheduled_time': '17:00 IST (5:00 PM)',
            'jobs_count': len(schedule.get_jobs())
        }

# Global scheduler instance
_global_scheduler: Optional[DailyScheduler] = None

def get_scheduler() -> DailyScheduler:
    """Get or create global scheduler instance"""
    global _global_scheduler
    if _global_scheduler is None:
        _global_scheduler = DailyScheduler()
    return _global_scheduler

def start_daily_scheduler():
    """Start the global daily scheduler"""
    scheduler = get_scheduler()
    scheduler.start()

def stop_daily_scheduler():
    """Stop the global daily scheduler"""
    scheduler = get_scheduler()
    scheduler.stop()

# For backward compatibility
DailyScheduler = DailyScheduler