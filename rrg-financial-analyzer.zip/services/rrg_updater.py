"""
Enhanced RRG updater with database integration and improved error handling
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from config import BENCHMARK_TICKER
from rrg_calculator import compute_rrg
from utils.logger import setup_logger, log_function_call
from utils.data_validator import DataValidator
from database.operations import DatabaseOperations

logger = setup_logger(__name__)

class RRGUpdater:
    """Enhanced RRG updater with comprehensive error handling and database integration"""
    
    def __init__(self):
        self.benchmark_ticker = BENCHMARK_TICKER
        self.validator = DataValidator()
        self.db_ops = DatabaseOperations()
    
    @log_function_call
    def load_price_data(self) -> pd.DataFrame:
        """
        Load price data from database with validation
        
        Returns:
            DataFrame: Combined price and benchmark data
        """
        try:
            # Load stock prices from database
            price_df = self.db_ops.get_stock_prices()
            if price_df.empty:
                raise ValueError("No stock price data found in database")
            
            # Load benchmark data from database
            benchmark_df = self.db_ops.get_benchmark_data()
            if benchmark_df.empty:
                raise ValueError("No benchmark data found in database")
            
            # Validate data
            price_valid, price_errors = self.validator.validate_price_data(price_df)
            benchmark_valid, benchmark_errors = self.validator.validate_price_data(benchmark_df)
            
            if not price_valid:
                logger.error(f"Price data validation failed: {price_errors}")
                raise ValueError(f"Price data validation failed: {price_errors}")
            
            if not benchmark_valid:
                logger.error(f"Benchmark data validation failed: {benchmark_errors}")
                raise ValueError(f"Benchmark data validation failed: {benchmark_errors}")
            
            # Combine data
            combined_df = pd.concat([price_df, benchmark_df], ignore_index=True)
            combined_df['Date'] = pd.to_datetime(combined_df['Date'])
            
            logger.info(f"Loaded combined data: {len(combined_df)} records")
            return combined_df
            
        except Exception as e:
            logger.error(f"Error loading price data: {str(e)}")
            raise
    
    @log_function_call
    def update_rrg_data(self) -> bool:
        """
        Update RRG data with latest calculations
        
        Returns:
            bool: Success status
        """
        try:
            # Log the start of update operation
            start_time = datetime.now()
            self.db_ops.log_data_update(
                update_type='rrg_data',
                status='started',
                started_at=start_time
            )
            
            # Load combined price data
            price_df = self.load_price_data()
            
            # Get list of tickers excluding benchmark
            tickers = price_df['Ticker'].unique().tolist()
            tickers = [t for t in tickers if t != self.benchmark_ticker]
            
            if not tickers:
                logger.error("No stock tickers found for RRG calculation")
                self.db_ops.log_data_update(
                    update_type='rrg_data',
                    status='failed',
                    error_message="No stock tickers found",
                    started_at=start_time
                )
                return False
            
            logger.info(f"Calculating RRG for {len(tickers)} tickers")
            
            # Calculate RRG snapshot for latest date
            df_rrg = compute_rrg(price_df, tickers, benchmark=self.benchmark_ticker)
            
            if df_rrg is None or df_rrg.empty:
                logger.error("RRG calculation returned empty result")
                self.db_ops.log_data_update(
                    update_type='rrg_data',
                    status='failed',
                    error_message="RRG calculation returned empty result",
                    started_at=start_time
                )
                return False
            
            # Validate RRG data
            is_valid, errors = self.validator.validate_rrg_data(df_rrg)
            if not is_valid:
                logger.warning(f"RRG data validation issues: {errors}")
            
            # Add current date
            latest_date = price_df['Date'].max()
            df_rrg['Date'] = latest_date
            
            # Save RRG data to database
            success = self.db_ops.save_rrg_data(df_rrg)
            
            if success:
                logger.info(f"✅ RRG data updated for {latest_date.date()} ({len(df_rrg)} stocks)")
                self.db_ops.log_data_update(
                    update_type='rrg_data',
                    status='success',
                    records_processed=len(df_rrg),
                    started_at=start_time
                )
                return True
            else:
                logger.error("Failed to save RRG data to database")
                self.db_ops.log_data_update(
                    update_type='rrg_data',
                    status='failed',
                    error_message="Failed to save RRG data to database",
                    started_at=start_time
                )
                return False
                
        except Exception as e:
            logger.error(f"Error updating RRG data: {str(e)}")
            self.db_ops.log_data_update(
                update_type='rrg_data',
                status='failed',
                error_message=str(e),
                started_at=start_time if 'start_time' in locals() else datetime.now()
            )
            return False
    
    def get_rrg_summary(self) -> dict:
        """
        Get summary of current RRG data from database
        
        Returns:
            dict: RRG data summary
        """
        try:
            # Get basic summary from database operations
            summary = self.db_ops.get_data_summary()
            
            if 'rrg_data' not in summary:
                return {'exists': False, 'message': 'No RRG data found in database'}
            
            rrg_summary = summary['rrg_data']
            
            # Enhance with additional details
            enhanced_summary = {
                'exists': True,
                'total_records': rrg_summary.get('total_records', 0),
                'unique_tickers': rrg_summary.get('unique_tickers', 0),
                'latest_date': rrg_summary.get('latest_date')
            }
            
            # Get latest quadrant distribution
            latest_data = self.db_ops.get_latest_rrg_data()
            if not latest_data.empty:
                enhanced_summary['latest_quadrant_distribution'] = (
                    latest_data['Quadrant'].value_counts().to_dict()
                )
            
            return enhanced_summary
            
        except Exception as e:
            logger.error(f"Error getting RRG summary: {str(e)}")
            return {'exists': False, 'error': str(e)}
    
    def cleanup_old_data(self, keep_days: int = 365) -> bool:
        """
        Clean up old RRG data to manage database size
        
        Args:
            keep_days: Number of days of data to keep
            
        Returns:
            bool: Success status
        """
        try:
            # Get current RRG data
            all_rrg_data = self.db_ops.get_rrg_data()
            
            if all_rrg_data.empty:
                logger.info("No RRG data to clean up")
                return True
            
            # Calculate cutoff date
            cutoff_date = datetime.now() - timedelta(days=keep_days)
            
            # Count records that would be removed
            old_records = len(all_rrg_data[all_rrg_data['Date'] < cutoff_date])
            
            if old_records > 0:
                logger.info(f"Would remove {old_records} old records (older than {cutoff_date.date()})")
                # Note: Actual deletion would require implementing delete operations in DatabaseOperations
                # For now, just log the cleanup intention
                return True
            else:
                logger.info("No old data to clean up")
                return True
            
        except Exception as e:
            logger.error(f"Error cleaning up RRG data: {str(e)}")
            return False
    
    def get_update_history(self, limit: int = 10) -> pd.DataFrame:
        """
        Get recent update history from database logs
        
        Args:
            limit: Number of recent updates to return
            
        Returns:
            DataFrame with update history
        """
        try:
            # This would require implementing a query method in DatabaseOperations
            # For now, return empty DataFrame
            return pd.DataFrame(columns=['update_type', 'status', 'records_processed', 'started_at', 'completed_at'])
            
        except Exception as e:
            logger.error(f"Error getting update history: {str(e)}")
            return pd.DataFrame()

# Legacy functions for backward compatibility
def load_price_data():
    """Legacy function for backward compatibility"""
    updater = RRGUpdater()
    return updater.load_price_data()

def update_rrg_data():
    """Legacy function for backward compatibility"""
    updater = RRGUpdater()
    return updater.update_rrg_data()

# Main execution
if __name__ == "__main__":
    updater = RRGUpdater()
    
    # Show current summary
    summary = updater.get_rrg_summary()
    if summary['exists']:
        print("📊 Current RRG Data Summary:")
        print(f"   Total Records: {summary['total_records']}")
        print(f"   Unique Tickers: {summary['unique_tickers']}")
        if summary.get('latest_date'):
            print(f"   Latest Date: {summary['latest_date'].date()}")
        if 'latest_quadrant_distribution' in summary:
            print("   Latest Quadrant Distribution:")
            for quadrant, count in summary['latest_quadrant_distribution'].items():
                print(f"      {quadrant}: {count}")
        print()
    
    # Update RRG data
    success = updater.update_rrg_data()
    
    if success:
        print("✅ RRG update completed successfully")
        
        # Optional: Clean up old data (keep last 2 years)
        cleanup_success = updater.cleanup_old_data(keep_days=730)
        if cleanup_success:
            print("🧹 Data cleanup completed")
    else:
        print("❌ RRG update failed")
        exit(1)
