"""
Simplified Data service for managing stock price data operations
"""
import pandas as pd
import yfinance as yf
import streamlit as st
from datetime import datetime, timedelta
from typing import List, Optional
from config import BENCHMARK_TICKER
from database.operations import DatabaseOperations
import logging

logger = logging.getLogger(__name__)

class DataService:
    """Handles stock price data fetching and database operations"""
    
    def __init__(self):
        self.db_ops = DatabaseOperations()
    
    def fetch_stock_data(self, ticker: str, period: str = "5y") -> Optional[pd.DataFrame]:
        """Fetch stock data from Yahoo Finance"""
        try:
            # Add .NS suffix for Indian stocks if not present
            if not ticker.endswith('.NS') and ticker != BENCHMARK_TICKER:
                ticker_symbol = f"{ticker}.NS"
            else:
                ticker_symbol = ticker
            
            logger.info(f"Fetching data for {ticker_symbol}")
            
            # Fetch data from Yahoo Finance
            stock = yf.Ticker(ticker_symbol)
            df = stock.history(period=period)
            
            if df.empty:
                logger.warning(f"No data returned for {ticker_symbol}")
                return None
            
            # Prepare data for database
            df = df.reset_index()
            df['Ticker'] = ticker_symbol
            df = df[['Date', 'Close', 'Ticker']]
            df.columns = ['Date', 'Close', 'Ticker']
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {ticker}: {str(e)}")
            return None
    
    def add_single_ticker(self, ticker: str) -> bool:
        """Add a single ticker to the database"""
        try:
            df = self.fetch_stock_data(ticker)
            if df is not None:
                # Save to database
                success = self.db_ops.save_stock_prices(df)
                if success:
                    logger.info(f"Successfully added {ticker}")
                    return True
            return False
        except Exception as e:
            logger.error(f"Error adding ticker {ticker}: {str(e)}")
            return False
    
    def refresh_all_data(self) -> bool:
        """Refresh data for all tickers in session state - optimized version"""
        try:
            # Get ticker list from session state
            if 'ticker_list' not in st.session_state or not st.session_state.ticker_list:
                logger.error("No ticker list found in session state")
                return False
            
            # This method is now just a fallback - the actual fetching is handled in the UI
            # to provide better progress feedback and prevent concurrent executions
            logger.info("refresh_all_data called - should be handled by UI for better UX")
            return True
            
        except Exception as e:
            logger.error(f"Error in refresh_all_data: {str(e)}")
            return False
    
    def remove_tickers(self, tickers_to_remove: List[str]) -> bool:
        """Remove specified tickers from database"""
        try:
            # This would require implementing delete operations in DatabaseOperations
            # For now, just log the request
            logger.info(f"Request to remove tickers: {tickers_to_remove}")
            return True
        except Exception as e:
            logger.error(f"Error removing tickers: {str(e)}")
            return False
    
    def get_data_summary(self) -> dict:
        """Get summary of current data"""
        try:
            summary = self.db_ops.get_data_summary()
            return summary
        except Exception as e:
            logger.error(f"Error getting data summary: {str(e)}")
            return {}