"""
Fast and efficient data service optimized for performance
"""
import pandas as pd
import yfinance as yf
import streamlit as st
from datetime import datetime
from typing import List, Optional
from config import BENCHMARK_TICKER
from database.operations import DatabaseOperations
import logging
import time

logger = logging.getLogger(__name__)

class FastDataService:
    """Optimized data service for fast fetching"""
    
    def __init__(self):
        self.db_ops = DatabaseOperations()
    
    def fetch_ticker_data_fast(self, ticker: str) -> Optional[pd.DataFrame]:
        """Fetch single ticker data efficiently"""
        try:
            # Add .NS suffix for Indian stocks
            if not ticker.endswith('.NS') and ticker != BENCHMARK_TICKER:
                symbol = f"{ticker}.NS"
            else:
                symbol = ticker
            
            # Quick fetch with shorter timeout
            stock = yf.Ticker(symbol)
            df = stock.history(period="5y", timeout=10)
            
            if df.empty:
                return None
            
            # Prepare for database
            df = df.reset_index()
            df['Ticker'] = symbol
            df = df[['Date', 'Close', 'Ticker']].copy()
            
            return df
            
        except Exception as e:
            logger.error(f"Failed to fetch {ticker}: {str(e)}")
            return None
    
    def batch_fetch_tickers(self, tickers: List[str], progress_callback=None) -> dict:
        """Fetch multiple tickers with progress tracking"""
        results = {'success': [], 'failed': []}
        total = len(tickers)
        
        # Fetch NIFTY 50 first
        if progress_callback:
            progress_callback(0, total + 1, "Fetching NIFTY 50...")
        
        benchmark_df = self.fetch_ticker_data_fast(BENCHMARK_TICKER)
        if benchmark_df is not None:
            self.db_ops.save_benchmark_data(benchmark_df)
            logger.info("NIFTY 50 data saved")
        
        # Fetch each ticker
        for i, ticker in enumerate(tickers):
            if progress_callback:
                progress_callback(i + 1, total + 1, f"Fetching {ticker}...")
            
            try:
                df = self.fetch_ticker_data_fast(ticker)
                if df is not None:
                    if self.db_ops.save_stock_prices(df):
                        results['success'].append(ticker)
                        logger.info(f"✓ {ticker}")
                    else:
                        results['failed'].append(ticker)
                        logger.error(f"✗ {ticker} (save failed)")
                else:
                    results['failed'].append(ticker)
                    logger.error(f"✗ {ticker} (fetch failed)")
                
                # Small delay to prevent rate limiting
                time.sleep(0.1)
                
            except Exception as e:
                results['failed'].append(ticker)
                logger.error(f"✗ {ticker}: {str(e)}")
        
        return results
    
    def quick_update_all(self) -> bool:
        """Quick update all tickers from session state"""
        if 'ticker_list' not in st.session_state:
            return False
        
        tickers = st.session_state.ticker_list
        results = self.batch_fetch_tickers(tickers)
        
        success_count = len(results['success'])
        total_count = len(tickers)
        
        logger.info(f"Quick update: {success_count}/{total_count} successful")
        return success_count > 0