"""
Enhanced price data manager with database integration
"""
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from typing import List, Optional
from config import (
    START_DATE, END_DATE, YFINANCE_RETRY_COUNT, YFINANCE_TIMEOUT
)
from utils.logger import setup_logger, log_function_call
from utils.data_validator import DataValidator
from database.operations import DatabaseOperations

logger = setup_logger(__name__)

class PriceDataManager:
    """Enhanced price data manager with database integration"""
    
    def __init__(self):
        self.validator = DataValidator()
        self.db_ops = DatabaseOperations()
    
    @log_function_call
    def fetch_5y_price(self, ticker: str) -> Optional[pd.DataFrame]:
        """
        Fetch 5-year price data for a ticker with retry logic
        
        Args:
            ticker: Stock ticker symbol
            
        Returns:
            DataFrame with price data or None if failed
        """
        yf_ticker = ticker if ticker.endswith('.NS') else ticker + '.NS'
        
        for attempt in range(YFINANCE_RETRY_COUNT):
            try:
                logger.debug(f"Fetching {yf_ticker} (attempt {attempt + 1})")
                
                df = yf.download(
                    yf_ticker,
                    start=START_DATE,
                    end=END_DATE,
                    progress=False,
                    timeout=YFINANCE_TIMEOUT
                )
                
                if df is None or df.empty:
                    logger.warning(f"No data returned for {yf_ticker}")
                    continue
                
                # Handle multi-level columns from yfinance
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.droplevel(1)
                
                df = df[['Close']].reset_index()
                df['Ticker'] = yf_ticker
                
                # Validate data
                is_valid, errors = self.validator.validate_price_data(df)
                if not is_valid:
                    logger.warning(f"Data validation failed for {yf_ticker}: {errors}")
                    continue
                
                logger.info(f"Successfully fetched {len(df)} records for {yf_ticker}")
                return df
                
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed for {yf_ticker}: {str(e)}")
                if attempt == YFINANCE_RETRY_COUNT - 1:
                    logger.error(f"All attempts failed for {yf_ticker}")
        
        return None
    
    @log_function_call
    def fetch_and_save_stock_data(self, ticker: str) -> bool:
        """
        Fetch and save stock data for a single ticker to database
        
        Args:
            ticker: Stock ticker symbol
            
        Returns:
            bool: Success status
        """
        try:
            # Fetch data
            data = self.fetch_5y_price(ticker)
            if data is None:
                return False
            
            # Save to database
            success = self.db_ops.save_stock_prices(data)
            if success:
                logger.info(f"Successfully saved data for {ticker}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error fetching/saving data for {ticker}: {str(e)}")
            return False
    
    @log_function_call
    def load_existing_data(self) -> pd.DataFrame:
        """Load existing price data from database"""
        try:
            df = self.db_ops.get_stock_prices()
            logger.debug(f"Loaded existing data: {len(df)} records")
            return df
            
        except Exception as e:
            logger.error(f"Error loading existing data: {str(e)}")
            return pd.DataFrame(columns=['Date', 'Close', 'Ticker'])
