"""
Enhanced dashboard component with Apple-inspired design
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from components.charts import ChartComponents
from database.operations import DatabaseOperations
from config import COLORS, RRG_COLORS

class DashboardComponent:
    """Main dashboard component with enhanced visualizations"""
    
    def __init__(self):
        self.db_ops = DatabaseOperations()
        self.charts = ChartComponents()
    
    def render_dashboard(self, sidebar_options: Dict[str, Any]):
        """Render the main dashboard"""
        # Custom CSS injection
        st.markdown("""
            <style>
                .metric-card {
                    background: white;
                    padding: 1.5rem;
                    border-radius: 12px;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                    border: 1px solid #E5E7EB;
                    text-align: center;
                    transition: all 0.2s ease;
                }
                .metric-card:hover {
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
                    transform: translateY(-1px);
                }
                .metric-value {
                    font-size: 2rem;
                    font-weight: 700;
                    color: #3B82F6;
                    margin: 0;
                }
                .metric-label {
                    font-size: 0.875rem;
                    font-weight: 500;
                    color: #6B7280;
                    margin: 0.5rem 0 0 0;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                }
            </style>
        """, unsafe_allow_html=True)
        
        # App header
        st.markdown("""
            <div class="app-header">
                <h1>RRG Financial Data Analyzer</h1>
                <p>Real-time Relative Rotation Graph analysis with intelligent insights</p>
            </div>
        """, unsafe_allow_html=True)
        
        # Load latest data
        with st.spinner("Loading dashboard data..."):
            latest_rrg_data = self.db_ops.get_latest_rrg_data()
            data_summary = self.db_ops.get_data_summary()
        
        # Render metrics
        self._render_metrics(data_summary, latest_rrg_data)
        
        # Main content
        if not latest_rrg_data.empty:
            self._render_main_rrg_chart(latest_rrg_data, sidebar_options)
            self._render_analysis_sections(latest_rrg_data, sidebar_options)
        else:
            self._render_empty_state()
    
    def _render_metrics(self, data_summary: Dict[str, Any], rrg_data: pd.DataFrame):
        """Render key metrics cards"""
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_stocks = data_summary.get('stock_prices', {}).get('unique_tickers', 0)
            st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{total_stocks}</div>
                    <div class="metric-label">Total Stocks</div>
                </div>
            """, unsafe_allow_html=True)
        
        with col2:
            latest_date = data_summary.get('rrg_data', {}).get('latest_date')
            last_update = latest_date.strftime('%m/%d') if latest_date else 'N/A'
            st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{last_update}</div>
                    <div class="metric-label">Last Update</div>
                </div>
            """, unsafe_allow_html=True)
        
        with col3:
            leading_count = len(rrg_data[rrg_data['Quadrant'] == 'Leading']) if not rrg_data.empty else 0
            st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value" style="color: #10B981;">{leading_count}</div>
                    <div class="metric-label">Leading Stocks</div>
                </div>
            """, unsafe_allow_html=True)
        
        with col4:
            total_records = data_summary.get('stock_prices', {}).get('total_records', 0)
            records_display = f"{total_records/1000:.1f}K" if total_records > 1000 else str(total_records)
            st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{records_display}</div>
                    <div class="metric-label">Data Points</div>
                </div>
            """, unsafe_allow_html=True)
    
    def _render_main_rrg_chart(self, rrg_data: pd.DataFrame, sidebar_options: Dict[str, Any]):
        """Render the main RRG chart"""
        st.markdown("## 📈 Relative Rotation Graph")
        
        # Chart options
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            st.markdown("**Current market positioning and momentum analysis**")
        
        with col2:
            show_tails = st.checkbox("Show Tails", value=sidebar_options.get('analysis_options', {}).get('show_tails', True))
        
        with col3:
            auto_fit = st.checkbox("Auto Fit", value=True)
        
        # Load historical data for tails if needed
        historical_data = None
        if show_tails:
            date_range = sidebar_options.get('analysis_options', {}).get('date_range', {})
            start_date = date_range.get('start_date', datetime.now() - timedelta(days=30))
            end_date = date_range.get('end_date', datetime.now())
            
            historical_data = self.db_ops.get_rrg_data(
                start_date=start_date,
                end_date=end_date
            )
        
        # Create and display chart
        rrg_chart = self.charts.create_rrg_chart(
            rrg_data=rrg_data,
            show_tails=show_tails,
            historical_data=historical_data
        )
        
        st.plotly_chart(rrg_chart, use_container_width=True)
        
        # Chart insights
        self._render_chart_insights(rrg_data)
    
    def _render_chart_insights(self, rrg_data: pd.DataFrame):
        """Render insights below the main chart"""
        st.markdown("### 💡 Key Insights")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Quadrant distribution
            quadrant_dist = rrg_data['Quadrant'].value_counts()
            
            st.markdown("**Quadrant Distribution:**")
            for quadrant, count in quadrant_dist.items():
                color = RRG_COLORS.get(quadrant, COLORS['secondary'])
                percentage = (count / len(rrg_data)) * 100
                st.markdown(f"""
                    <div style="display: flex; align-items: center; margin: 0.5rem 0;">
                        <div style="width: 12px; height: 12px; background: {color}; border-radius: 50%; margin-right: 0.5rem;"></div>
                        <span><strong>{quadrant}:</strong> {count} stocks ({percentage:.1f}%)</span>
                    </div>
                """, unsafe_allow_html=True)
        
        with col2:
            # Top performers
            if not rrg_data.empty:
                top_rs_ratio = rrg_data.nlargest(3, 'RS_Ratio')
                
                st.markdown("**Top RS Ratio:**")
                for _, stock in top_rs_ratio.iterrows():
                    ticker_clean = stock['Ticker'].replace('.NS', '')
                    st.markdown(f"• **{ticker_clean}**: {stock['RS_Ratio']:.2f}")
    
    def _render_analysis_sections(self, rrg_data: pd.DataFrame, sidebar_options: Dict[str, Any]):
        """Render additional analysis sections"""
        tab1, tab2, tab3 = st.tabs(["📊 Distribution", "📈 Performance", "📋 Details"])
        
        with tab1:
            self._render_distribution_analysis(rrg_data)
        
        with tab2:
            self._render_performance_analysis(rrg_data, sidebar_options)
        
        with tab3:
            self._render_detailed_table(rrg_data)
    
    def _render_distribution_analysis(self, rrg_data: pd.DataFrame):
        """Render quadrant distribution analysis"""
        col1, col2 = st.columns(2)
        
        with col1:
            # Pie chart
            pie_chart = self.charts.create_quadrant_distribution_chart(rrg_data)
            st.plotly_chart(pie_chart, use_container_width=True)
        
        with col2:
            # Summary statistics
            st.markdown("### 📊 Statistics")
            
            stats_data = []
            for quadrant in ['Leading', 'Improving', 'Lagging', 'Weakening']:
                quadrant_data = rrg_data[rrg_data['Quadrant'] == quadrant]
                if not quadrant_data.empty:
                    stats_data.append({
                        'Quadrant': quadrant,
                        'Count': len(quadrant_data),
                        'Avg RS Ratio': quadrant_data['RS_Ratio'].mean(),
                        'Avg RS Momentum': quadrant_data['RS_Momentum'].mean()
                    })
            
            if stats_data:
                stats_df = pd.DataFrame(stats_data)
                st.dataframe(stats_df, hide_index=True)
    
    def _render_performance_analysis(self, rrg_data: pd.DataFrame, sidebar_options: Dict[str, Any]):
        """Render performance analysis"""
        if rrg_data.empty:
            st.info("No performance data available")
            return
        
        # Historical timeline
        date_range = sidebar_options.get('analysis_options', {}).get('date_range', {})
        start_date = date_range.get('start_date', datetime.now() - timedelta(days=90))
        end_date = date_range.get('end_date', datetime.now())
        
        historical_data = self.db_ops.get_rrg_data(start_date=start_date, end_date=end_date)
        
        if not historical_data.empty:
            # Get top 5 performers
            top_performers = rrg_data.nlargest(5, 'RS_Ratio')['Ticker'].tolist()
            
            timeline_chart = self.charts.create_performance_timeline(historical_data, top_performers)
            st.plotly_chart(timeline_chart, use_container_width=True)
        else:
            st.info("No historical data available for performance analysis")
    
    def _render_detailed_table(self, rrg_data: pd.DataFrame):
        """Render detailed data table"""
        if rrg_data.empty:
            st.info("No data available")
            return
        
        # Clean up ticker names
        display_data = rrg_data.copy()
        display_data['Ticker'] = display_data['Ticker'].str.replace('.NS', '')
        
        # Round numerical columns
        display_data['RS_Ratio'] = display_data['RS_Ratio'].round(2)
        display_data['RS_Momentum'] = display_data['RS_Momentum'].round(2)
        
        # Sort by RS Ratio
        display_data = display_data.sort_values('RS_Ratio', ascending=False)
        
        # Add rank
        display_data['Rank'] = range(1, len(display_data) + 1)
        
        # Reorder columns
        display_data = display_data[['Rank', 'Ticker', 'Quadrant', 'RS_Ratio', 'RS_Momentum']]
        
        st.dataframe(
            display_data,
            hide_index=True,
            use_container_width=True,
            column_config={
                "Rank": st.column_config.NumberColumn("Rank", width="small"),
                "Ticker": st.column_config.TextColumn("Ticker", width="medium"),
                "Quadrant": st.column_config.TextColumn("Quadrant", width="medium"),
                "RS_Ratio": st.column_config.NumberColumn("RS Ratio", format="%.2f"),
                "RS_Momentum": st.column_config.NumberColumn("RS Momentum", format="%.2f")
            }
        )
    
    def _render_empty_state(self):
        """Render empty state when no data is available"""
        st.markdown("""
            <div style="
                text-align: center;
                padding: 4rem 2rem;
                background: white;
                border-radius: 12px;
                border: 1px solid #E5E7EB;
                margin: 2rem 0;
            ">
                <h3 style="color: #6B7280; margin-bottom: 1rem;">No Data Available</h3>
                <p style="color: #9CA3AF; margin-bottom: 2rem;">
                    It looks like there's no RRG data to display. This could be because:
                </p>
                <ul style="color: #9CA3AF; text-align: left; max-width: 400px; margin: 0 auto 2rem;">
                    <li>No stock data has been loaded yet</li>
                    <li>RRG calculations haven't been performed</li>
                    <li>Database connection issues</li>
                </ul>
                <p style="color: #9CA3AF;">
                    Try refreshing the data using the sidebar controls or check the Data Management section.
                </p>
            </div>
        """, unsafe_allow_html=True)
