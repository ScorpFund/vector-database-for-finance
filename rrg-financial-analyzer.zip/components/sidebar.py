"""
Enhanced sidebar component with Apple-inspired design
"""
import streamlit as st
import pandas as pd
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from config import COLORS
from database.operations import DatabaseOperations

class SidebarComponent:
    """Enhanced sidebar component for navigation and controls"""
    
    def __init__(self):
        self.db_ops = DatabaseOperations()
    
    def render_sidebar(self) -> Dict[str, Any]:
        """Render the main sidebar with controls and options"""
        with st.sidebar:
            # App logo/title
            st.markdown("""
                <div style="
                    background: linear-gradient(135deg, #3B82F6 0%, #8B9DC3 100%);
                    padding: 1rem;
                    border-radius: 12px;
                    text-align: center;
                    margin-bottom: 2rem;
                    color: white;
                ">
                    <h2 style="margin: 0; font-weight: 700;">RRG Analyzer</h2>
                    <p style="margin: 0.5rem 0 0 0; opacity: 0.9; font-size: 0.9rem;">Financial Intelligence</p>
                </div>
            """, unsafe_allow_html=True)
            
            # Navigation
            page = st.selectbox(
                "📍 Navigate",
                options=["Dashboard", "RRG Analysis", "Stock Management", "Data Management", "Settings"],
                key="page_selector"
            )
            
            st.divider()
            
            # Quick stats
            self._render_quick_stats()
            
            st.divider()
            
            # Analysis controls
            analysis_options = self._render_analysis_controls()
            
            st.divider()
            
            # Data controls
            data_options = self._render_data_controls()
            
            st.divider()
            
            # About section
            self._render_about_section()
            
            return {
                "page": page,
                "analysis_options": analysis_options,
                "data_options": data_options
            }
    
    def _render_quick_stats(self):
        """Render quick statistics in sidebar"""
        st.markdown("### 📊 Quick Stats")
        
        try:
            summary = self.db_ops.get_data_summary()
            
            if summary:
                # Stock data stats
                if 'stock_prices' in summary:
                    stock_stats = summary['stock_prices']
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.metric(
                            label="Stocks",
                            value=stock_stats.get('unique_tickers', 0)
                        )
                    
                    with col2:
                        st.metric(
                            label="Records",
                            value=f"{stock_stats.get('total_records', 0)/1000:.1f}K" 
                            if stock_stats.get('total_records', 0) > 1000 
                            else stock_stats.get('total_records', 0)
                        )
                
                # RRG data stats
                if 'rrg_data' in summary:
                    rrg_stats = summary['rrg_data']
                    latest_date = rrg_stats.get('latest_date')
                    
                    if latest_date:
                        st.metric(
                            label="Latest Update",
                            value=latest_date.strftime('%Y-%m-%d')
                        )
            else:
                st.info("No data available")
                
        except Exception as e:
            st.error(f"Error loading stats: {str(e)}")
    
    def _render_analysis_controls(self) -> Dict[str, Any]:
        """Render analysis control options"""
        st.markdown("### 🔧 Analysis Options")
        
        options = {}
        
        # Chart options
        options['show_tails'] = st.checkbox(
            "Show Historical Tails",
            value=True,
            help="Display historical movement trails on RRG chart"
        )
        
        options['tail_length'] = st.slider(
            "Tail Length (days)",
            min_value=5,
            max_value=30,
            value=10,
            help="Number of historical days to show in tails"
        )
        
        # Date range selection
        date_range = st.selectbox(
            "Analysis Period",
            options=["Last 30 days", "Last 90 days", "Last 6 months", "Last 1 year", "All time"],
            index=1
        )
        
        options['date_range'] = self._convert_date_range(date_range)
        
        # Sector filter (placeholder for future implementation)
        options['sector_filter'] = st.multiselect(
            "Sector Filter",
            options=["Technology", "Banking", "Pharma", "Auto", "FMCG", "Energy"],
            help="Filter stocks by sector (coming soon)"
        )
        
        return options
    
    def _render_data_controls(self) -> Dict[str, Any]:
        """Render data management controls"""
        st.markdown("### 💾 Data Controls")
        
        options = {}
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Refresh", use_container_width=True):
                options['refresh_data'] = True
        
        with col2:
            if st.button("📊 Update RRG", use_container_width=True):
                options['update_rrg'] = True
        
        # Auto-refresh toggle
        options['auto_refresh'] = st.checkbox(
            "Auto-refresh (5 min)",
            value=False,
            help="Automatically refresh data every 5 minutes"
        )
        
        # Data export
        if st.button("📤 Export Data", use_container_width=True):
            options['export_data'] = True
        
        return options
    
    def _render_about_section(self):
        """Render about section"""
        with st.expander("ℹ️ About"):
            st.markdown("""
                **RRG Financial Data Analyzer**
                
                A comprehensive tool for Relative Rotation Graph analysis 
                of stock market data with real-time insights and beautiful 
                visualizations.
                
                **Features:**
                - Real-time RRG analysis
                - Historical trend tracking
                - Interactive visualizations
                - Database-backed storage
                - Apple-inspired design
                
                **Version:** 2.0.0
                """)
    
    def _convert_date_range(self, range_str: str) -> Dict[str, datetime]:
        """Convert date range string to datetime objects"""
        end_date = datetime.now()
        
        if range_str == "Last 30 days":
            start_date = end_date - timedelta(days=30)
        elif range_str == "Last 90 days":
            start_date = end_date - timedelta(days=90)
        elif range_str == "Last 6 months":
            start_date = end_date - timedelta(days=180)
        elif range_str == "Last 1 year":
            start_date = end_date - timedelta(days=365)
        else:  # All time
            start_date = end_date - timedelta(days=365*5)  # 5 years max
        
        return {
            "start_date": start_date,
            "end_date": end_date
        }
    
    def render_stock_selector(self, available_tickers: List[str]) -> List[str]:
        """Render stock selection interface"""
        st.markdown("### 🎯 Stock Selection")
        
        if not available_tickers:
            st.warning("No stocks available")
            return []
        
        # Search functionality
        search_term = st.text_input(
            "🔍 Search Stocks",
            placeholder="Type ticker symbol or company name..."
        )
        
        # Filter tickers based on search
        if search_term:
            filtered_tickers = [
                ticker for ticker in available_tickers 
                if search_term.upper() in ticker.upper()
            ]
        else:
            filtered_tickers = available_tickers
        
        # Multi-select for stocks
        selected_stocks = st.multiselect(
            "Select Stocks",
            options=filtered_tickers,
            default=filtered_tickers[:5] if len(filtered_tickers) >= 5 else filtered_tickers,
            help="Select stocks for analysis"
        )
        
        # Quick selection buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("Select All", use_container_width=True):
                selected_stocks = filtered_tickers
        
        with col2:
            if st.button("Top 10", use_container_width=True):
                selected_stocks = filtered_tickers[:10]
        
        with col3:
            if st.button("Clear", use_container_width=True):
                selected_stocks = []
        
        return selected_stocks
    
    def render_quadrant_filter(self) -> List[str]:
        """Render quadrant filter options"""
        st.markdown("### 🎯 Quadrant Filter")
        
        quadrants = ["Leading", "Improving", "Lagging", "Weakening"]
        
        selected_quadrants = st.multiselect(
            "Show Quadrants",
            options=quadrants,
            default=quadrants,
            help="Filter stocks by RRG quadrant"
        )
        
        return selected_quadrants
