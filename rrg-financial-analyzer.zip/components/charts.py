"""
Enhanced chart components with Apple-inspired styling
"""
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
import streamlit as st
from config import COLORS, RRG_COLORS, CHART_HEIGHT, CHART_WIDTH

class ChartComponents:
    """Enhanced chart components for RRG visualization"""
    
    @staticmethod
    def create_rrg_chart(rrg_data: pd.DataFrame, show_tails: bool = True, 
                        historical_data: pd.DataFrame = None) -> go.Figure:
        """
        Create enhanced RRG chart with Apple-inspired styling
        
        Args:
            rrg_data: Current RRG data
            show_tails: Whether to show historical tails
            historical_data: Historical RRG data for tails
            
        Returns:
            Plotly figure object
        """
        fig = go.Figure()
        
        # Chart background and styling
        fig.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family="Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"),
            title=dict(
                text="Relative Rotation Graph",
                font=dict(size=24, weight=600, color=COLORS['text_primary']),
                x=0.5,
                y=0.95
            ),
            showlegend=True,
            legend=dict(
                x=1.02,
                y=1,
                bgcolor='rgba(255,255,255,0.9)',
                bordercolor=COLORS['border'],
                borderwidth=1
            ),
            width=CHART_WIDTH,
            height=CHART_HEIGHT,
            margin=dict(l=60, r=120, t=80, b=60)
        )
        
        # Add quadrant background
        fig.add_shape(
            type="rect",
            x0=100, y0=100, x1=200, y1=200,
            fillcolor=RRG_COLORS['Leading'],
            opacity=0.1,
            layer="below",
            line=dict(width=0)
        )
        
        fig.add_shape(
            type="rect",
            x0=0, y0=100, x1=100, y1=200,
            fillcolor=RRG_COLORS['Improving'],
            opacity=0.1,
            layer="below",
            line=dict(width=0)
        )
        
        fig.add_shape(
            type="rect",
            x0=0, y0=0, x1=100, y1=100,
            fillcolor=RRG_COLORS['Lagging'],
            opacity=0.1,
            layer="below",
            line=dict(width=0)
        )
        
        fig.add_shape(
            type="rect",
            x0=100, y0=0, x1=200, y1=100,
            fillcolor=RRG_COLORS['Weakening'],
            opacity=0.1,
            layer="below",
            line=dict(width=0)
        )
        
        # Add quadrant lines
        fig.add_hline(y=100, line_dash="dash", line_color=COLORS['border'], line_width=1)
        fig.add_vline(x=100, line_dash="dash", line_color=COLORS['border'], line_width=1)
        
        # Add quadrant labels
        fig.add_annotation(x=150, y=150, text="Leading", showarrow=False, 
                          font=dict(size=12, color=COLORS['text_secondary']))
        fig.add_annotation(x=50, y=150, text="Improving", showarrow=False,
                          font=dict(size=12, color=COLORS['text_secondary']))
        fig.add_annotation(x=50, y=50, text="Lagging", showarrow=False,
                          font=dict(size=12, color=COLORS['text_secondary']))
        fig.add_annotation(x=150, y=50, text="Weakening", showarrow=False,
                          font=dict(size=12, color=COLORS['text_secondary']))
        
        # Add historical tails if requested and data available
        if show_tails and historical_data is not None and not historical_data.empty:
            ChartComponents._add_historical_tails(fig, historical_data)
        
        # Add current points
        if not rrg_data.empty:
            for _, row in rrg_data.iterrows():
                color = RRG_COLORS.get(row['Quadrant'], COLORS['secondary'])
                
                fig.add_trace(go.Scatter(
                    x=[row['RS_Ratio']],
                    y=[row['RS_Momentum']],
                    mode='markers+text',
                    marker=dict(
                        size=12,
                        color=color,
                        line=dict(width=2, color='white'),
                        symbol='circle'
                    ),
                    text=[row['Ticker'].replace('.NS', '')],
                    textposition="top center",
                    textfont=dict(size=10, color=COLORS['text_primary'], family="Inter"),
                    name=row['Quadrant'],
                    showlegend=False,
                    hovertemplate=(
                        f"<b>{row['Ticker'].replace('.NS', '')}</b><br>"
                        f"RS Ratio: {row['RS_Ratio']:.2f}<br>"
                        f"RS Momentum: {row['RS_Momentum']:.2f}<br>"
                        f"Quadrant: {row['Quadrant']}<extra></extra>"
                    )
                ))
        
        # Update axes
        fig.update_xaxes(
            title="RS Ratio",
            title_font=dict(size=14, color=COLORS['text_primary']),
            showgrid=True,
            gridwidth=1,
            gridcolor=COLORS['border'],
            zeroline=False,
            range=[0, 200]
        )
        
        fig.update_yaxes(
            title="RS Momentum",
            title_font=dict(size=14, color=COLORS['text_primary']),
            showgrid=True,
            gridwidth=1,
            gridcolor=COLORS['border'],
            zeroline=False,
            range=[-50, 50]
        )
        
        return fig
    
    @staticmethod
    def _add_historical_tails(fig: go.Figure, historical_data: pd.DataFrame, tail_length: int = 10):
        """Add historical tails to RRG chart"""
        try:
            if historical_data.empty:
                return
            
            # Get unique tickers
            tickers = historical_data['Ticker'].unique()
            
            for ticker in tickers:
                ticker_data = historical_data[historical_data['Ticker'] == ticker].copy()
                ticker_data = ticker_data.sort_values('Date').tail(tail_length)
                
                if len(ticker_data) < 2:
                    continue
                
                # Create tail line
                fig.add_trace(go.Scatter(
                    x=ticker_data['RS_Ratio'],
                    y=ticker_data['RS_Momentum'],
                    mode='lines',
                    line=dict(
                        color=COLORS['secondary'],
                        width=1,
                        dash='dot'
                    ),
                    name=f"{ticker.replace('.NS', '')} tail",
                    showlegend=False,
                    hoverinfo='skip'
                ))
                
        except Exception as e:
            st.error(f"Error adding historical tails: {str(e)}")
    
    @staticmethod
    def create_quadrant_distribution_chart(rrg_data: pd.DataFrame) -> go.Figure:
        """Create quadrant distribution pie chart"""
        if rrg_data.empty:
            return go.Figure()
        
        quadrant_counts = rrg_data['Quadrant'].value_counts()
        
        colors = [RRG_COLORS.get(q, COLORS['secondary']) for q in quadrant_counts.index]
        
        fig = go.Figure(data=[go.Pie(
            labels=quadrant_counts.index,
            values=quadrant_counts.values,
            hole=0.4,
            marker=dict(colors=colors, line=dict(color='white', width=2)),
            textfont=dict(size=12, family="Inter"),
            hovertemplate="<b>%{label}</b><br>Count: %{value}<br>Percentage: %{percent}<extra></extra>"
        )])
        
        fig.update_layout(
            title=dict(
                text="Quadrant Distribution",
                font=dict(size=18, weight=600, color=COLORS['text_primary']),
                x=0.5
            ),
            font=dict(family="Inter, -apple-system, BlinkMacSystemFont"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=True,
            legend=dict(
                orientation="v",
                x=1.02,
                y=0.5
            ),
            height=400,
            margin=dict(l=20, r=120, t=60, b=20)
        )
        
        return fig
    
    @staticmethod
    def create_performance_timeline(historical_data: pd.DataFrame, selected_tickers: List[str]) -> go.Figure:
        """Create performance timeline chart"""
        if historical_data.empty or not selected_tickers:
            return go.Figure()
        
        fig = go.Figure()
        
        for ticker in selected_tickers[:5]:  # Limit to 5 tickers for readability
            ticker_data = historical_data[historical_data['Ticker'] == ticker].copy()
            ticker_data = ticker_data.sort_values('Date')
            
            if ticker_data.empty:
                continue
            
            fig.add_trace(go.Scatter(
                x=ticker_data['Date'],
                y=ticker_data['RS_Ratio'],
                mode='lines',
                name=ticker.replace('.NS', ''),
                line=dict(width=2),
                hovertemplate=(
                    f"<b>{ticker.replace('.NS', '')}</b><br>"
                    "Date: %{x}<br>"
                    "RS Ratio: %{y:.2f}<extra></extra>"
                )
            ))
        
        fig.update_layout(
            title=dict(
                text="RS Ratio Timeline",
                font=dict(size=18, weight=600, color=COLORS['text_primary']),
                x=0.5
            ),
            xaxis_title="Date",
            yaxis_title="RS Ratio",
            font=dict(family="Inter, -apple-system, BlinkMacSystemFont"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=True,
            legend=dict(
                x=1.02,
                y=1
            ),
            height=400,
            margin=dict(l=60, r=120, t=60, b=60)
        )
        
        # Add horizontal line at 100
        fig.add_hline(y=100, line_dash="dash", line_color=COLORS['border'], line_width=1)
        
        fig.update_xaxes(
            showgrid=True,
            gridwidth=1,
            gridcolor=COLORS['border']
        )
        
        fig.update_yaxes(
            showgrid=True,
            gridwidth=1,
            gridcolor=COLORS['border']
        )
        
        return fig
    
    @staticmethod
    def create_sector_heatmap(rrg_data: pd.DataFrame, sector_mapping: Dict[str, str] = None) -> go.Figure:
        """Create sector-wise performance heatmap"""
        if rrg_data.empty:
            return go.Figure()
        
        # If no sector mapping provided, create a simple view
        if not sector_mapping:
            # Group by quadrant for visualization
            quadrant_summary = rrg_data.groupby('Quadrant').agg({
                'RS_Ratio': 'mean',
                'RS_Momentum': 'mean',
                'Ticker': 'count'
            }).round(2)
            
            fig = go.Figure(data=go.Heatmap(
                z=quadrant_summary['RS_Ratio'].values.reshape(1, -1),
                x=quadrant_summary.index,
                y=['Average RS Ratio'],
                colorscale='RdYlBu_r',
                showscale=True,
                hovertemplate="Quadrant: %{x}<br>Avg RS Ratio: %{z:.2f}<extra></extra>"
            ))
            
            fig.update_layout(
                title=dict(
                    text="Quadrant Performance Heatmap",
                    font=dict(size=18, weight=600, color=COLORS['text_primary']),
                    x=0.5
                ),
                font=dict(family="Inter, -apple-system, BlinkMacSystemFont"),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                height=200,
                margin=dict(l=60, r=60, t=60, b=60)
            )
        
        return fig
