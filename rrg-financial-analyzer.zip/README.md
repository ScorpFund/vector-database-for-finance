# RRG Financial Data Analyzer

A comprehensive financial data visualization application built with Streamlit that provides Relative Rotation Graph (RRG) analysis for stock market data with Apple-inspired design and PostgreSQL integration.

## Features

- **CSV Ticker Management**: Upload CSV files to manage your stock ticker list
- **Automatic Daily Updates**: Scheduled data fetching at 5:00 PM IST
- **Historical RRG Data**: Complete historical storage for tail visualization
- **Apple-Inspired Design**: Clean, modern interface with calming colors
- **PostgreSQL Integration**: Robust database storage for all financial data
- **Real-time Progress Tracking**: Visual feedback during data operations

## Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL database
- Internet connection for Yahoo Finance data

### Installation

1. Clone this repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Set up environment variables:
   ```bash
   export DATABASE_URL="postgresql://username:password@host:port/database"
   ```
4. Run the application:
   ```bash
   streamlit run app.py --server.port 5000
   ```

### Using the Application

1. **Ticker Management**: 
   - Go to "Ticker Management" page
   - Upload a CSV file with ticker symbols (column should be named 'ticker', 'symbol', or 'stock')
   - Update your ticker list

2. **Data Management**:
   - Go to "Data Management" page  
   - Click "Fetch All Price Data" to download historical prices
   - Click "Calculate RRG Data" to generate RRG analysis

3. **Scheduler**:
   - Set up automatic daily updates at 5:00 PM
   - Monitor update status and history

4. **RRG Analysis**:
   - View interactive RRG charts
   - Filter by quadrants
   - Analyze stock performance and trends

## Project Structure

```
rrg-analyzer-project/
├── app.py                 # Main Streamlit application
├── config.py             # Configuration settings
├── rrg_calculator.py     # RRG calculation engine
├── database/             # Database models and operations
├── services/             # Data services and business logic
├── components/           # UI components
├── utils/               # Utility functions
└── styles/              # CSS styling
```

## Configuration

Key settings in `config.py`:
- `BENCHMARK_TICKER`: Default benchmark (^NSEI for NIFTY 50)
- `DATABASE_URL`: PostgreSQL connection string
- Color schemes and UI preferences

## Data Flow

1. **CSV Upload** → Ticker list management
2. **Yahoo Finance API** → Historical price data
3. **PostgreSQL** → Data storage and retrieval
4. **RRG Engine** → Mathematical calculations
5. **Plotly** → Interactive visualizations

## Dependencies

- streamlit: Web application framework
- pandas: Data manipulation
- plotly: Interactive charts
- sqlalchemy: Database ORM
- yfinance: Yahoo Finance API
- psycopg2-binary: PostgreSQL adapter
- schedule: Task scheduling

## License

This project is open source and available under the MIT License.

## Support

For questions or issues, please create an issue in the GitHub repository.